# My Keyboard (عربي / English)

1. افتح المجلد في Android Studio (File > Open) ودع Gradle يكمل المزامنة.
2. شغّل التطبيق على جهاز أو محاكي.
3. من الشاشة الأولى: "تفعيل الكيبورد" ثم "اختيار الكيبورد".
4. لقاموس أكبر ضع words_en.txt و words_ar.txt في app/src/main/assets (كلمة في كل سطر).
5. لتغيير اسم الحزمة بدّل com.example.mykeyboard في build.gradle.kts والمجلدات والـ package.
