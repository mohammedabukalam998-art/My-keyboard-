# My Keyboard (عربي / English)

1. افتح المجلد في Android Studio (File > Open) ودع Gradle يكمل المزامنة.
2. شغّل التطبيق على جهاز أو محاكي.
3. من الشاشة الأولى: "تفعيل الكيبورد" ثم "اختيار الكيبورد".
4. لقاموس أكبر ضع words_en.txt و words_ar.txt في app/src/main/assets (كلمة في كل سطر).
5. لتغيير اسم الحزمة بدّل com.example.mykeyboard في build.gradle.kts والمجلدات والـ package.

## البناء عبر GitHub
ارفع المشروع إلى مستودع GitHub، ثم افتح تبويب Actions وانتظر انتهاء "Build APK"،
ونزّل الملف app-debug.apk من قسم Artifacts. ثبّته على هاتفك (اسمح بالتثبيت من مصدر غير معروف).

## القاموس
- عند البناء على GitHub يُنزَّل قاموسا en_50k و ar_50k تلقائياً من مشروع FrequencyWords
  (بيانات مستخرجة من OpenSubtitles، ترخيص CC BY-SA 4.0: https://github.com/hermitdave/FrequencyWords).
- يمكنك أيضاً استيراد ملف نصي من شاشة التطبيق (كلمة في كل سطر، أو "كلمة عدد").
