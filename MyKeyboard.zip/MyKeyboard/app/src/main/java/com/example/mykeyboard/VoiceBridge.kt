package com.example.mykeyboard

/** جسر بسيط بين VoiceInputActivity وخدمة الكيبورد (نفس العملية). */
object VoiceBridge {
    var listener: ((String) -> Unit)? = null
}
