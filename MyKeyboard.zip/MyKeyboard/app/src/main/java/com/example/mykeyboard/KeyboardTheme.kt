package com.example.mykeyboard

import android.content.Context
import android.graphics.Color
import androidx.core.graphics.ColorUtils

data class KeyboardTheme(
    val bg: Int,       // خلفية الكيبورد
    val key: Int,      // المفاتيح العادية
    val special: Int,  // المفاتيح الخاصة (حذف، Enter، ...)
    val active: Int,   // Shift المفعّل، الفئة المختارة
    val pressed: Int,  // لون المفتاح أثناء الضغط
    val text: Int,     // لون النص
    val popup: Int     // الفقاعة المنبثقة
)

object Themes {
    const val KEY_THEME = "theme"
    const val KEY_BG = "custom_bg"
    const val KEY_KEY = "custom_key"
    const val KEY_TEXT = "custom_text"
    const val DEF_BG = "#263238"
    const val DEF_KEY = "#37474F"
    const val DEF_TEXT = "#ECEFF1"

    val ids = listOf("auto", "light", "dark", "amoled", "blue", "green", "rose", "custom")
    val names = listOf("تلقائي (حسب النظام)", "فاتح", "داكن", "أسود (AMOLED)", "أزرق", "أخضر", "وردي", "مخصص")

    private fun t(bg: String, key: String, special: String, active: String, pressed: String, text: String, popup: String) =
        KeyboardTheme(
            Color.parseColor(bg), Color.parseColor(key), Color.parseColor(special),
            Color.parseColor(active), Color.parseColor(pressed), Color.parseColor(text), Color.parseColor(popup)
        )

    private val LIGHT = t("#D9DCE0", "#FFFFFF", "#B8BEC6", "#90CAF9", "#BDBDBD", "#000000", "#FFFFFF")
    private val DARK = t("#1B1B1D", "#3A3A3C", "#2A2A2C", "#3D6FB5", "#5A5A5C", "#FFFFFF", "#4A4A4C")
    private val AMOLED = t("#000000", "#1C1C1E", "#111111", "#2E5C99", "#3A3A3C", "#FFFFFF", "#2C2C2E")
    private val BLUE = t("#0F2A47", "#1F4B7A", "#163A60", "#4FA3F7", "#2E6AA8", "#FFFFFF", "#2E6AA8")
    private val GREEN = t("#12301F", "#21553A", "#18402B", "#4CC38A", "#2F7A52", "#FFFFFF", "#2F7A52")
    private val ROSE = t("#F8E1E7", "#FFFFFF", "#F0B6C6", "#F06292", "#F4C2CF", "#3A1F28", "#FFFFFF")

    private fun parse(s: String?, default: String): Int =
        try { Color.parseColor(s ?: default) } catch (e: IllegalArgumentException) { Color.parseColor(default) }

    /** يشتق باقي الألوان من ثلاثة: الخلفية، المفتاح، النص */
    fun custom(bg: Int, key: Int, text: Int) = KeyboardTheme(
        bg = bg,
        key = key,
        special = ColorUtils.blendARGB(key, text, 0.15f),
        active = ColorUtils.blendARGB(key, Color.parseColor("#4A90D9"), 0.65f),
        pressed = ColorUtils.blendARGB(key, text, 0.28f),
        text = text,
        popup = key
    )

    private fun auto(c: Context) = KeyboardTheme(
        c.getColor(R.color.keyboard_bg), c.getColor(R.color.key_bg), c.getColor(R.color.key_special_bg),
        c.getColor(R.color.key_active_bg), c.getColor(R.color.key_pressed), c.getColor(R.color.key_text),
        c.getColor(R.color.popup_bg)
    )

    fun resolve(context: Context): KeyboardTheme {
        val p = context.getSharedPreferences(FeedbackHelper.PREFS, Context.MODE_PRIVATE)
        return when (p.getString(KEY_THEME, "auto")) {
            "light" -> LIGHT
            "dark" -> DARK
            "amoled" -> AMOLED
            "blue" -> BLUE
            "green" -> GREEN
            "rose" -> ROSE
            "custom" -> custom(
                parse(p.getString(KEY_BG, DEF_BG), DEF_BG),
                parse(p.getString(KEY_KEY, DEF_KEY), DEF_KEY),
                parse(p.getString(KEY_TEXT, DEF_TEXT), DEF_TEXT)
            )
            else -> auto(context)
        }
    }
}
