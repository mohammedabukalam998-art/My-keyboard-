package com.example.mykeyboard

import android.content.Context

/**
 * توقّع الكلمة التالية: يتعلم من كتابتك (الكلمة السابقة ← الكلمة التالية)
 * ويكمّل بقائمة صغيرة من العبارات الشائعة. كل شيء يُحفظ على جهازك فقط.
 */
class NextWordPredictor(context: Context) {

    private val prefs = context.getSharedPreferences("nextword", Context.MODE_PRIVATE)

    fun predict(prev: String, max: Int = 3): List<String> {
        val key = normalize(prev)
        if (key.isEmpty()) return emptyList()
        val learned = parse(prefs.getString(key, null)).sortedByDescending { it.second }.map { it.first }
        return (learned + SEEDS[key].orEmpty()).distinct().take(max)
    }

    fun learn(prev: String, next: String) {
        val p = normalize(prev)
        val n = normalize(next)
        if (p.isEmpty() || n.isEmpty()) return
        if (n.length < 2 && n !in setOf("a", "i", "و")) return
        val list = parse(prefs.getString(p, null)).toMutableList()
        val i = list.indexOfFirst { it.first == n }
        if (i >= 0) list[i] = Pair(n, list[i].second + 1) else list.add(Pair(n, 1))
        val top = list.sortedByDescending { it.second }.take(8)
        prefs.edit().putString(p, top.joinToString(",") { "${it.first}:${it.second}" }).apply()
    }

    private fun parse(raw: String?): List<Pair<String, Int>> {
        if (raw.isNullOrEmpty()) return emptyList()
        return raw.split(",").mapNotNull { part ->
            val w = part.substringBeforeLast(':')
            val c = part.substringAfterLast(':').toIntOrNull()
            if (w.isEmpty() || c == null) null else Pair(w, c)
        }
    }

    companion object {
        fun normalize(w: String): String = buildString {
            for (c in w.lowercase()) {
                if (c in '\u064B'..'\u065F' || c == '\u0670' || c == '\u0640') continue
                append(c)
            }
        }

        /** الكلمة السابقة، بشرط أن ينتهي النص بمسافة (لا سطر جديد ولا علامة ترقيم) */
        fun wordBefore(text: String): String? {
            if (text.isEmpty() || !text.last().isWhitespace() || text.last() == '\n') return null
            val w = text.trimEnd().takeLastWhile {
                it.isLetter() || it == '\'' || Character.getType(it) == Character.NON_SPACING_MARK.toInt()
            }
            return if (w.isEmpty()) null else normalize(w)
        }

        private val SEEDS: Map<String, List<String>> = mapOf(
            // عربي
            "السلام" to listOf("عليكم"), "وعليكم" to listOf("السلام"), "ورحمة" to listOf("الله"),
            "كيف" to listOf("حالك", "الحال", "أصبحت"), "صباح" to listOf("الخير", "النور"),
            "مساء" to listOf("الخير", "النور"), "شكرا" to listOf("لك", "جزيلا", "لكم"),
            "جزاك" to listOf("الله"), "الله" to listOf("يعطيك", "يسلمك", "يبارك"),
            "إن" to listOf("شاء"), "ان" to listOf("شاء"), "بارك" to listOf("الله"),
            "ما" to listOf("شاء"), "الحمد" to listOf("لله"), "أهلا" to listOf("وسهلا", "بك"),
            "من" to listOf("فضلك"), "كل" to listOf("عام"), "عيد" to listOf("مبارك", "سعيد"),
            "تصبح" to listOf("على"), "على" to listOf("خير"), "لا" to listOf("بأس", "مشكلة"),
            "أنا" to listOf("بخير", "في"), "يعطيك" to listOf("العافية"),
            // English
            "thank" to listOf("you"), "how" to listOf("are", "is", "to"),
            "good" to listOf("morning", "night", "luck"), "i" to listOf("am", "will", "have"),
            "see" to listOf("you"), "have" to listOf("a"), "what" to listOf("is", "are", "do"),
            "can" to listOf("you", "i"), "please" to listOf("let", "send"),
            "looking" to listOf("forward"), "let" to listOf("me", "us"), "talk" to listOf("to"),
            "happy" to listOf("birthday", "new"), "best" to listOf("regards", "wishes"),
            "do" to listOf("you", "not"), "are" to listOf("you"), "i'm" to listOf("not", "going"),
            "no" to listOf("problem"), "of" to listOf("course")
        )
    }
}
