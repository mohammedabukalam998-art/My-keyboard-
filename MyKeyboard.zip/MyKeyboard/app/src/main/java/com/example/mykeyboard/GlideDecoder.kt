package com.example.mykeyboard

import android.graphics.PointF
import kotlin.math.hypot
import kotlin.math.ln

/**
 * يحوّل مسار الإصبع إلى كلمات: نبحث في القاموس عن الكلمات التي حروفها
 * (بالترتيب) على المسار، ثم نقارن شكل المسار بالمسار المثالي للكلمة مع تفضيل الأشيع.
 */
class GlideDecoder(private val dictionary: SimpleDictionary) {

    private fun normChar(c: Char, arabic: Boolean): Char {
        val l = c.lowercaseChar()
        if (!arabic) return l
        return when (l) {
            'أ', 'إ', 'آ', 'ٱ' -> 'ا'
            'ى' -> 'ي'
            'ة' -> 'ه'
            else -> l
        }
    }

    private fun collapse(s: String): String {
        val sb = StringBuilder()
        for (ch in s) if (sb.isEmpty() || sb.last() != ch) sb.append(ch)
        return sb.toString()
    }

    private fun resample(pts: List<PointF>, n: Int): List<PointF> {
        val d = DoubleArray(pts.size)
        for (i in 1 until pts.size) {
            d[i] = d[i - 1] + hypot((pts[i].x - pts[i - 1].x).toDouble(), (pts[i].y - pts[i - 1].y).toDouble())
        }
        val total = d.last()
        if (total < 1e-3) return List(n) { pts[0] }
        val out = ArrayList<PointF>(n)
        var j = 1
        for (k in 0 until n) {
            val target = total * k / (n - 1)
            while (j < pts.size - 1 && d[j] < target) j++
            val seg = d[j] - d[j - 1]
            val t = if (seg < 1e-6) 0.0 else (target - d[j - 1]) / seg
            out.add(
                PointF(
                    (pts[j - 1].x + (pts[j].x - pts[j - 1].x) * t).toFloat(),
                    (pts[j - 1].y + (pts[j].y - pts[j - 1].y) * t).toFloat()
                )
            )
        }
        return out
    }

    private fun shapeDistance(a: List<PointF>, b: List<PointF>): Double {
        val ra = resample(a, 24)
        val rb = resample(b, 24)
        var sum = 0.0
        for (i in ra.indices) sum += hypot((ra[i].x - rb[i].x).toDouble(), (ra[i].y - rb[i].y).toDouble())
        return sum / ra.size
    }

    fun decode(rawPath: List<PointF>, keys: List<GlideKey>, arabic: Boolean, max: Int = 3): List<String> {
        if (rawPath.size < 3 || keys.size < 5) return emptyList()
        val keyW = keys.map { it.w }.average().toFloat()

        // 1) نخفف النقاط المتقاربة
        val path = ArrayList<PointF>()
        val minStep = keyW * 0.12f
        for (p in rawPath) {
            val last = path.lastOrNull()
            if (last == null || hypot(p.x - last.x, p.y - last.y) >= minStep) path.add(p)
        }
        val end = rawPath.last()
        val tail = path.last()
        if (tail.x != end.x || tail.y != end.y) path.add(end)
        if (path.size < 3) return emptyList()

        // 2) لكل حرف (مُطبَّع) نختار المفتاح الأقرب للمسار (مثل ة و ه)
        val groups = HashMap<Char, MutableList<GlideKey>>()
        for (k in keys) groups.getOrPut(normChar(k.ch, arabic)) { ArrayList() }.add(k)
        val resolved = HashMap<Char, GlideKey>()
        for ((c, list) in groups) {
            val best = list.minByOrNull { k -> path.minOf { p -> hypot(p.x - k.cx, p.y - k.cy) } } ?: continue
            resolved[c] = best
        }

        // 3) الأحرف القريبة من كل نقطة على المسار
        val radius = keyW * 0.75f
        val near: List<Set<Char>> = path.map { p ->
            resolved.filter { (_, k) -> hypot(p.x - k.cx, p.y - k.cy) <= radius }.keys
        }
        val firstChars = HashSet<Char>()
        for (i in 0 until minOf(2, near.size)) firstChars.addAll(near[i])
        val lastChars = HashSet<Char>()
        for (i in maxOf(0, near.size - 2) until near.size) lastChars.addAll(near[i])
        if (firstChars.isEmpty() || lastChars.isEmpty()) return emptyList()

        // 4) المرشحون من القاموس
        val scored = ArrayList<Pair<String, Double>>()
        for (c in dictionary.glideCandidates(firstChars, arabic)) {
            val letters = collapse(c.key)
            if (letters.length < 2 || letters.last() !in lastChars) continue
            if (letters.any { it !in resolved }) continue

            // الحروف يجب أن تظهر بالترتيب على المسار
            var idx = 0
            var ok = true
            for (ch in letters) {
                while (idx < near.size && ch !in near[idx]) idx++
                if (idx >= near.size) {
                    ok = false
                    break
                }
            }
            if (!ok) continue

            val ideal = letters.map { PointF(resolved.getValue(it).cx, resolved.getValue(it).cy) }
            val d = shapeDistance(path, ideal) / keyW
            if (d > 1.0) continue
            scored.add(Pair(c.word, d + 0.06 * ln(c.rank + 2.0)))
        }
        return scored.sortedBy { it.second }.map { it.first }.distinct().take(max)
    }
}
