package com.example.mykeyboard

import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

enum class FeedbackType { STANDARD, SPACE, DELETE, RETURN }

/** الاهتزاز + صوت النقر. يُقرأ التفعيل/الإيقاف من إعدادات التطبيق. */
class FeedbackHelper(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val vibrator: Vibrator? = findVibrator(context)
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Suppress("DEPRECATION")
    private fun findVibrator(context: Context): Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

    fun press(type: FeedbackType) {
        if (prefs.getBoolean(KEY_VIBRATE, true)) vibrate()
        if (prefs.getBoolean(KEY_SOUND, true)) {
            val effect = when (type) {
                FeedbackType.SPACE -> AudioManager.FX_KEYPRESS_SPACEBAR
                FeedbackType.DELETE -> AudioManager.FX_KEYPRESS_DELETE
                FeedbackType.RETURN -> AudioManager.FX_KEYPRESS_RETURN
                FeedbackType.STANDARD -> AudioManager.FX_KEYPRESS_STANDARD
            }
            audio.playSoundEffect(effect)
        }
    }

    /** اهتزاز خفيف فقط (بدون صوت)، يُستخدم عند تحريك المؤشر بالسحب */
    fun tick() {
        if (prefs.getBoolean(KEY_VIBRATE, true)) vibrate()
    }

    private fun vibrate() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val effect = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
        } else {
            VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE)
        }
        v.vibrate(effect)
    }

    companion object {
        const val PREFS = "settings"
        const val KEY_VIBRATE = "vibrate"
        const val KEY_SOUND = "sound"
        const val KEY_AUTO_LANG = "auto_lang"
        const val KEY_LANG = "preferred_lang"
    }
}
