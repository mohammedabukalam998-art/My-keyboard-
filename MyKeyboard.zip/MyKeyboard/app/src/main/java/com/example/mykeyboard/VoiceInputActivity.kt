package com.example.mykeyboard

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * نشاط شفاف يفتح واجهة التعرف على الصوت الخاصة بالنظام، ثم يعيد النص للكيبورد.
 * لأن واجهة النظام هي من يستخدم الميكروفون، لا نحتاج إذن RECORD_AUDIO.
 */
class VoiceInputActivity : ComponentActivity() {

    private val launcher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) VoiceBridge.listener?.invoke(text)
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return // أُعيد إنشاء النشاط: النتيجة ستصل عبر launcher

        val lang = intent.getStringExtra(EXTRA_LANGUAGE) ?: "en-US"
        val recognize = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        }
        try {
            launcher.launch(recognize)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "لا يوجد تطبيق للتعرف على الصوت في هذا الجهاز", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    companion object {
        const val EXTRA_LANGUAGE = "language"
    }
}
