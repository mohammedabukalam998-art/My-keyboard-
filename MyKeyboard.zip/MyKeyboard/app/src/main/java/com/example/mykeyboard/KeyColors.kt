package com.example.mykeyboard

import android.content.Context
import android.graphics.Color
import androidx.core.graphics.ColorUtils
import org.json.JSONException
import org.json.JSONObject

/**
 * ألوان المفاتيح: قوس قزح تلقائي (تدرج حسب العمود والصف) + ألوان يدوية لكل مفتاح.
 * اللون اليدوي يتغلب على قوس قزح، وقوس قزح يتغلب على لون الثيم.
 */
object KeyColors {
    const val PREF_RAINBOW = "rainbow_keys"
    private const val PREF_MAP = "key_colors_json"

    private fun prefs(c: Context) = c.getSharedPreferences(FeedbackHelper.PREFS, Context.MODE_PRIVATE)

    fun rainbow(c: Context): Boolean = prefs(c).getBoolean(PREF_RAINBOW, false)

    /** مفتاح ← لون. المفاتيح: حرف صغير (أو عربي/رمز) أو shift, delete, sym, lang, emoji, space, enter */
    fun load(c: Context): Map<String, Int> {
        val out = HashMap<String, Int>()
        try {
            val o = JSONObject(prefs(c).getString(PREF_MAP, "{}") ?: "{}")
            val names = o.keys()
            while (names.hasNext()) {
                val k = names.next()
                try {
                    out[k] = Color.parseColor(o.getString(k))
                } catch (e: IllegalArgumentException) {
                    // نتجاهل اللون التالف
                }
            }
        } catch (e: JSONException) {
            // بيانات تالفة
        }
        return out
    }

    fun save(c: Context, map: Map<String, Int>) {
        val o = JSONObject()
        for ((k, v) in map) o.put(k, String.format("#%06X", 0xFFFFFF and v))
        prefs(c).edit().putString(PREF_MAP, o.toString()).apply()
    }

    /** بصمة الإعدادات: إذا تغيّرت يعيد الكيبورد بناء الواجهة */
    fun signature(c: Context): String =
        (if (rainbow(c)) "1" else "0") + (prefs(c).getString(PREF_MAP, "") ?: "")

    /** لون قوس قزح: [frac] موضع العمود (0..1)، [row] رقم الصف */
    fun rainbowColor(frac: Float, row: Int, darkBase: Boolean): Int {
        val hue = (frac * 300f + row * 25f) % 360f
        val hsv = if (darkBase) floatArrayOf(hue, 0.55f, 0.62f) else floatArrayOf(hue, 0.32f, 0.98f)
        return Color.HSVToColor(hsv)
    }

    fun isDark(color: Int): Boolean = ColorUtils.calculateLuminance(color) < 0.5
    fun readableText(bg: Int): Int = if (isDark(bg)) Color.WHITE else Color.BLACK
    fun pressedFor(fill: Int): Int =
        ColorUtils.blendARGB(fill, if (isDark(fill)) Color.WHITE else Color.BLACK, 0.22f)
}
