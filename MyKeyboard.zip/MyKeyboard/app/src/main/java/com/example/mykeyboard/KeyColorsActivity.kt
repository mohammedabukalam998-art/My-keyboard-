package com.example.mykeyboard

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

/** اختيار لون لكل مفتاح بنفسك. اللون اليدوي يتغلب على ألوان قوس قزح والثيم. */
class KeyColorsActivity : ComponentActivity() {

    private var colors = HashMap<String, Int>()
    private lateinit var content: LinearLayout

    private val palette = listOf(
        "#EF5350", "#EC407A", "#AB47BC", "#7E57C2", "#5C6BC0", "#42A5F5",
        "#26C6DA", "#26A69A", "#66BB6A", "#9CCC65", "#D4E157", "#FFEE58",
        "#FFA726", "#FF7043", "#8D6E63", "#BDBDBD", "#FFFFFF", "#212121"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        colors = HashMap(KeyColors.load(this))
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(20), dp(20), dp(20), dp(20))
        val scroll = ScrollView(this)
        scroll.addView(content)
        setContentView(scroll)
        render()
    }

    private fun add(v: View) {
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(10)
        content.addView(v, lp)
    }

    private fun commit() {
        KeyColors.save(this, colors)
        render()
    }

    private fun render() {
        content.removeAllViews()

        val title = TextView(this)
        title.text = "ألوان المفاتيح"
        title.textSize = 20f
        add(title)

        val help = TextView(this)
        help.text = "المس أي مفتاح لاختيار لونه. اللون الذي تختاره يتغلب على قوس قزح وعلى لون الثيم. " +
            "تظهر التغييرات في الكيبورد عند فتحه من جديد."
        add(help)

        val bulk = Button(this)
        bulk.text = "لون واحد لكل الأحرف (عربي وإنجليزي)"
        bulk.setOnClickListener {
            pickColor("لون كل الأحرف") { c ->
                for (id in letterIds()) if (c == null) colors.remove(id) else colors[id] = c
                commit()
            }
        }
        add(bulk)

        val clear = Button(this)
        clear.text = "مسح كل الألوان المخصصة"
        clear.setOnClickListener {
            colors.clear()
            commit()
        }
        add(clear)

        section("الإنجليزية", "qwertyuiopasdfghjklzxcvbnm".map { it.toString() to it.toString().uppercase() })
        section("العربية", KeyboardLayouts.arabic.flatten().map { it.text to it.label })

        val symbols = (KeyboardLayouts.digits + KeyboardLayouts.symbols1 + KeyboardLayouts.symbols2)
            .flatten().map { it.text }.distinct().map { it to it }
        section("الأرقام والرموز", symbols)

        section(
            "المفاتيح الخاصة",
            listOf(
                "shift" to "⇧", "delete" to "⌫", "sym" to "123", "lang" to "🌐",
                "emoji" to "😊", "space" to "␣", "enter" to "↵"
            )
        )
    }

    private fun letterIds(): List<String> =
        "qwertyuiopasdfghjklzxcvbnm".map { it.toString() } + KeyboardLayouts.arabic.flatten().map { it.text }

    private fun section(name: String, items: List<Pair<String, String>>) {
        val label = TextView(this)
        label.text = name
        label.textSize = 16f
        add(label)

        val columns = 8
        val size = (resources.displayMetrics.widthPixels - dp(40)) / columns
        val grid = GridLayout(this)
        grid.columnCount = columns
        for ((id, text) in items) {
            val tv = TextView(this)
            tv.text = text
            tv.gravity = Gravity.CENTER
            tv.textSize = 16f
            val c = colors[id]
            tv.setBackgroundColor(c ?: Color.parseColor("#E0E0E0"))
            tv.setTextColor(if (c != null) KeyColors.readableText(c) else Color.BLACK)
            tv.setOnClickListener {
                pickColor("لون المفتاح: $text") { picked ->
                    if (picked == null) colors.remove(id) else colors[id] = picked
                    commit()
                }
            }
            val lp = GridLayout.LayoutParams()
            lp.width = size - dp(4)
            lp.height = dp(44)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            grid.addView(tv, lp)
        }
        add(grid)
    }

    /** نافذة اختيار لون: ألوان جاهزة أو كود #RRGGBB. onPick(null) = إزالة اللون. */
    private fun pickColor(title: String, onPick: (Int?) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), 0)

        lateinit var dialog: AlertDialog

        val pal = GridLayout(this)
        pal.columnCount = 6
        for (hex in palette) {
            val sw = TextView(this)
            val c = Color.parseColor(hex)
            sw.setBackgroundColor(c)
            sw.setOnClickListener {
                onPick(c)
                dialog.dismiss()
            }
            val lp = GridLayout.LayoutParams()
            lp.width = dp(44)
            lp.height = dp(44)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            pal.addView(sw, lp)
        }
        box.addView(pal)

        val field = EditText(this)
        field.hint = "أو اكتب كوداً مثل #FF9800"
        box.addView(field)

        dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("تطبيق") { _, _ ->
                try {
                    onPick(Color.parseColor(field.text.toString().trim()))
                } catch (e: IllegalArgumentException) {
                    Toast.makeText(this, "كود اللون غير صالح", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إزالة اللون") { _, _ -> onPick(null) }
            .setNeutralButton("إلغاء", null)
            .create()
        dialog.show()
    }
}
