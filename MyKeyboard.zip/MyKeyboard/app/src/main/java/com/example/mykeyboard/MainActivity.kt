package com.example.mykeyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.activity.ComponentActivity

/** شاشة الإعداد: تفعيل الكيبورد، اختياره، ضبط الاهتزاز والصوت، وحقل للتجربة. */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun add(v: View) = root.addView(
            v, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = pad / 2 }
        )

        val title = TextView(this)
        title.text = "لوحة المفاتيح (عربي / English)"
        title.textSize = 20f
        add(title)

        val enable = Button(this)
        enable.text = "1) تفعيل الكيبورد في إعدادات النظام"
        enable.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        add(enable)

        val choose = Button(this)
        choose.text = "2) اختيار الكيبورد"
        choose.setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        add(choose)

        val vib = Switch(this)
        vib.text = "اهتزاز عند الضغط"
        vib.isChecked = prefs.getBoolean(FeedbackHelper.KEY_VIBRATE, true)
        vib.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(FeedbackHelper.KEY_VIBRATE, c).apply() }
        add(vib)

        val snd = Switch(this)
        snd.text = "صوت النقر"
        snd.isChecked = prefs.getBoolean(FeedbackHelper.KEY_SOUND, true)
        snd.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(FeedbackHelper.KEY_SOUND, c).apply() }
        add(snd)

        val test = EditText(this)
        test.hint = "جرّب الكتابة هنا"
        add(test)

        setContentView(root)
    }
}
