package com.example.mykeyboard

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File

/** شاشة الإعداد: تفعيل الكيبورد، الاهتزاز والصوت، اختيار الثيم، وحقل للتجربة. */
class MainActivity : ComponentActivity() {

    private lateinit var preview: LinearLayout
    private var importArabic = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importDictionary(uri, importArabic)
    }

    /** ينسخ الملف النصي المختار إلى مجلد التطبيق، والكيبورد يحمّله تلقائياً */
    private fun importDictionary(uri: Uri, arabic: Boolean) {
        val name = if (arabic) SimpleDictionary.AR_FILE else SimpleDictionary.EN_FILE
        try {
            val target = File(filesDir, name)
            contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { out -> input.copyTo(out) }
            }
            val count = target.useLines { lines -> lines.count { it.isNotBlank() } }
            Toast.makeText(this, "تم استيراد $count سطر", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر قراءة الملف", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun add(v: View) = root.addView(
            v, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = pad / 2 }
        )

        val title = TextView(this)
        title.text = "لوحة المفاتيح (عربي / English)"
        title.textSize = 20f
        add(title)

        val enable = Button(this)
        enable.text = "1) تفعيل الكيبورد في إعدادات النظام"
        enable.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        add(enable)

        val choose = Button(this)
        choose.text = "2) اختيار الكيبورد"
        choose.setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        add(choose)

        val vib = Switch(this)
        vib.text = "اهتزاز عند الضغط"
        vib.isChecked = prefs.getBoolean(FeedbackHelper.KEY_VIBRATE, true)
        vib.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(FeedbackHelper.KEY_VIBRATE, c).apply() }
        add(vib)

        val snd = Switch(this)
        snd.text = "صوت النقر"
        snd.isChecked = prefs.getBoolean(FeedbackHelper.KEY_SOUND, true)
        snd.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(FeedbackHelper.KEY_SOUND, c).apply() }
        add(snd)

        val autoLang = Switch(this)
        autoLang.text = "تبديل اللغة تلقائياً (حسب النص والحقل)"
        autoLang.isChecked = prefs.getBoolean(FeedbackHelper.KEY_AUTO_LANG, true)
        autoLang.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(FeedbackHelper.KEY_AUTO_LANG, c).apply() }
        add(autoLang)

        val eastern = Switch(this)
        eastern.text = "أرقام عربية-هندية (١٢٣) في لوحة الأرقام"
        eastern.isChecked = prefs.getBoolean("eastern_digits", false)
        eastern.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("eastern_digits", c).apply() }
        add(eastern)

        val autoCorrect = Switch(this)
        autoCorrect.text = "التصحيح التلقائي للأخطاء الإملائية"
        autoCorrect.isChecked = prefs.getBoolean("autocorrect", true)
        autoCorrect.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("autocorrect", c).apply() }
        add(autoCorrect)

        val glideSwitch = Switch(this)
        glideSwitch.text = "الكتابة بالسحب (Glide)"
        glideSwitch.isChecked = prefs.getBoolean("glide", true)
        glideSwitch.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("glide", c).apply() }
        add(glideSwitch)

        val emojiSwitch = Switch(this)
        emojiSwitch.text = "اقتراح الإيموجي أثناء الكتابة"
        emojiSwitch.isChecked = prefs.getBoolean("emoji_suggest", true)
        emojiSwitch.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("emoji_suggest", c).apply() }
        add(emojiSwitch)

        val dictTitle = TextView(this)
        dictTitle.text = "القاموس (ملف نصي: كلمة في كل سطر، الأشيع أولاً)"
        add(dictTitle)

        val importAr = Button(this)
        importAr.text = "استيراد قاموس عربي"
        importAr.setOnClickListener {
            importArabic = true
            picker.launch(arrayOf("*/*"))
        }
        add(importAr)

        val importEn = Button(this)
        importEn.text = "استيراد قاموس إنجليزي"
        importEn.setOnClickListener {
            importArabic = false
            picker.launch(arrayOf("*/*"))
        }
        add(importEn)

        val resetDict = Button(this)
        resetDict.text = "العودة للقاموس الافتراضي"
        resetDict.setOnClickListener {
            File(filesDir, SimpleDictionary.AR_FILE).delete()
            File(filesDir, SimpleDictionary.EN_FILE).delete()
            Toast.makeText(this, "تمت إعادة القاموس الافتراضي", Toast.LENGTH_SHORT).show()
        }
        add(resetDict)

        val shortcutsBtn = Button(this)
        shortcutsBtn.text = "الاختصارات النصية"
        shortcutsBtn.setOnClickListener { startActivity(Intent(this, ShortcutsActivity::class.java)) }
        add(shortcutsBtn)

        val wordsBtn = Button(this)
        wordsBtn.text = "الكلمات المحفوظة"
        wordsBtn.setOnClickListener { startActivity(Intent(this, UserWordsActivity::class.java)) }
        add(wordsBtn)

        // ---------------- الذكاء الاصطناعي (اختياري) ----------------
        val aiTitle = TextView(this)
        aiTitle.text = "الذكاء الاصطناعي (اختياري)"
        aiTitle.textSize = 18f
        add(aiTitle)

        val aiNote = TextView(this)
        aiNote.text = "يعمل من لوحة 🛠 ثم ✨ داخل الكيبورد. النص الذي تطلب معالجته يُرسل إلى خوادم Anthropic " +
            "بمفتاح API الخاص بك، ويُحفظ المفتاح على جهازك فقط. لا يعمل في حقول كلمات المرور."
        add(aiNote)

        val aiKey = EditText(this)
        aiKey.hint = "مفتاح API (sk-ant-...)"
        aiKey.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        aiKey.setText(prefs.getString("ai_key", ""))
        add(aiKey)

        val aiModel = EditText(this)
        aiModel.hint = "اسم النموذج"
        aiModel.setText(prefs.getString("ai_model", AiClient.DEFAULT_MODEL))
        add(aiModel)

        val aiSave = Button(this)
        aiSave.text = "حفظ إعدادات الذكاء الاصطناعي"
        aiSave.setOnClickListener {
            prefs.edit()
                .putString("ai_key", aiKey.text.toString().trim())
                .putString("ai_model", aiModel.text.toString().trim().ifBlank { AiClient.DEFAULT_MODEL })
                .apply()
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
        }
        add(aiSave)

        // ---------------- الثيم ----------------
        val themeTitle = TextView(this)
        themeTitle.text = "الثيم"
        themeTitle.textSize = 18f
        add(themeTitle)

        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Themes.names)
        spinner.setSelection(Themes.ids.indexOf(prefs.getString(Themes.KEY_THEME, "auto")).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                prefs.edit().putString(Themes.KEY_THEME, Themes.ids[position]).apply()
                refreshPreview()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        add(spinner)

        preview = LinearLayout(this)
        preview.orientation = LinearLayout.HORIZONTAL
        preview.gravity = Gravity.CENTER
        preview.setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        add(preview)
        refreshPreview()

        val customTitle = TextView(this)
        customTitle.text = "ألوان مخصصة (للثيم \"مخصص\"، بصيغة #RRGGBB)"
        add(customTitle)

        val bgField = EditText(this)
        bgField.hint = "لون الخلفية"
        bgField.setText(prefs.getString(Themes.KEY_BG, Themes.DEF_BG))
        add(bgField)

        val keyField = EditText(this)
        keyField.hint = "لون المفاتيح"
        keyField.setText(prefs.getString(Themes.KEY_KEY, Themes.DEF_KEY))
        add(keyField)

        val textField = EditText(this)
        textField.hint = "لون النص"
        textField.setText(prefs.getString(Themes.KEY_TEXT, Themes.DEF_TEXT))
        add(textField)

        val apply = Button(this)
        apply.text = "تطبيق الألوان المخصصة"
        apply.setOnClickListener {
            val bg = bgField.text.toString().trim()
            val key = keyField.text.toString().trim()
            val text = textField.text.toString().trim()
            try {
                Color.parseColor(bg); Color.parseColor(key); Color.parseColor(text)
            } catch (e: IllegalArgumentException) {
                Toast.makeText(this, "أحد الألوان غير صالح، استخدم مثل #263238", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            prefs.edit()
                .putString(Themes.KEY_BG, bg).putString(Themes.KEY_KEY, key).putString(Themes.KEY_TEXT, text)
                .putString(Themes.KEY_THEME, "custom").apply()
            spinner.setSelection(Themes.ids.indexOf("custom"))
            refreshPreview()
        }
        add(apply)

        val test = EditText(this)
        test.hint = "جرّب الكتابة هنا"
        add(test)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    /** معاينة سريعة بألوان الثيم المختار */
    private fun refreshPreview() {
        val th = Themes.resolve(this)
        val d = resources.displayMetrics.density
        preview.removeAllViews()
        preview.setBackgroundColor(th.bg)

        fun keyView(label: String, fill: Int) {
            val tv = TextView(this)
            tv.text = label
            tv.textSize = 18f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(th.text)
            tv.setBackgroundColor(fill)
            val lp = LinearLayout.LayoutParams((44 * d).toInt(), (44 * d).toInt())
            lp.setMargins((3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt(), (3 * d).toInt())
            preview.addView(tv, lp)
        }
        keyView("A", th.key)
        keyView("ع", th.key)
        keyView("B", th.key)
        keyView("⇧", th.special)
        keyView("⌫", th.special)
        keyView("✓", th.active)
    }
}
