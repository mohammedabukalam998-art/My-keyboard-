package com.example.mykeyboard

/** كلمات مفتاحية (إنجليزي وعربي) لاقتراح إيموجي أثناء الكتابة. */
object EmojiKeywords {

    private val raw = listOf(
        "😀" to "grin smile happy joy سعيد ابتسامة فرح",
        "😂" to "lol laugh haha funny joy ضحك يضحك مضحك",
        "🤣" to "rofl lmao ضحك",
        "😊" to "blush happy smile خجل",
        "😍" to "love eyes crush حب عشق",
        "🥰" to "adore loving",
        "😘" to "kiss muah قبلة",
        "😎" to "cool sunglasses رائع",
        "🤔" to "think thinking hmm تفكير",
        "😢" to "sad cry tear حزين",
        "😭" to "sob crying بكاء",
        "😡" to "angry mad rage غاضب غضب",
        "😱" to "scream shock scared خوف صدمة",
        "😴" to "sleep tired sleepy نوم نعسان",
        "🤗" to "hug hugs عناق",
        "😉" to "wink غمزة",
        "🥳" to "party celebrate احتفال",
        "🤯" to "mindblown wow مذهول",
        "🥺" to "please pleading begging",
        "😇" to "angel innocent ملاك",
        "🤩" to "amazing starstruck مبهر",
        "😋" to "yummy delicious tasty لذيذ",
        "😷" to "mask sick ill كمامة",
        "🤒" to "fever sick مريض حرارة",
        "😰" to "worried anxious قلق",
        "🥵" to "hot heat حر",
        "🥶" to "cold freezing برد",
        "👍" to "like ok yes good approve thumbs اعجاب موافق جيد",
        "👎" to "dislike bad رفض سيء",
        "👏" to "clap bravo applause تصفيق",
        "🙌" to "praise hooray",
        "🙏" to "pray thanks thank dua شكرا دعاء رجاء",
        "💪" to "strong muscle power قوة عضلات",
        "👌" to "perfect تمام",
        "✌️" to "peace victory نصر سلام",
        "🤝" to "deal handshake agreement اتفاق مصافحة",
        "👋" to "hello hi bye wave مرحبا وداعا",
        "❤️" to "love heart red قلب حب",
        "💔" to "broken heartbreak مكسور",
        "🔥" to "fire hot lit نار",
        "✨" to "sparkle shine magic لمعان",
        "⭐" to "star نجمة",
        "🎉" to "congrats tada congratulations مبروك",
        "🎂" to "birthday cake ميلاد كعكة",
        "🎁" to "gift present هدية",
        "🚀" to "rocket launch fast صاروخ",
        "💡" to "idea bulb فكرة",
        "✅" to "done check complete تم صح",
        "❌" to "cross wrong error خطأ",
        "⚠️" to "warning caution تحذير",
        "☕" to "coffee tea drink قهوة شاي",
        "🍕" to "pizza بيتزا",
        "🍔" to "burger برجر",
        "🍎" to "apple fruit تفاح",
        "🌹" to "rose flower وردة ورد",
        "🌙" to "moon night قمر ليل",
        "☀️" to "sun sunny شمس",
        "🌈" to "rainbow قوس",
        "🎵" to "music song موسيقى اغنية",
        "⚽" to "football soccer كرة",
        "🚗" to "car drive سيارة",
        "✈️" to "plane flight travel طائرة سفر",
        "🏠" to "home house بيت منزل",
        "📱" to "phone mobile هاتف جوال",
        "💻" to "laptop computer حاسوب لابتوب",
        "📷" to "camera photo صورة كاميرا",
        "💰" to "money cash مال فلوس",
        "👑" to "king queen crown تاج ملك",
        "🕌" to "mosque مسجد جامع",
        "🤲" to "dua hands دعاء",
        "🐶" to "dog puppy كلب",
        "🐱" to "cat kitten قطة",
        "🦁" to "lion اسد",
        "🍫" to "chocolate شوكولاتة",
        "🎮" to "game gaming play لعبة",
        "📚" to "book books study read كتاب دراسة",
        "✏️" to "pencil write قلم كتابة",
        "⏰" to "alarm clock time ساعة وقت",
        "🔔" to "bell notification جرس تنبيه",
        "🔒" to "lock secure قفل",
        "🔑" to "key مفتاح",
        "💯" to "hundred score 100",
        "💥" to "boom explosion انفجار",
        "🏆" to "trophy winner cup كأس فائز",
        "🥇" to "gold medal ميدالية",
        "👀" to "eyes look see عيون نظر"
    )

    private val exact = HashMap<String, MutableList<String>>()

    init {
        for ((emoji, keys) in raw) {
            for (k in keys.split(" ")) {
                if (k.isNotEmpty()) exact.getOrPut(norm(k)) { ArrayList() }.add(emoji)
            }
        }
    }

    private fun norm(w: String): String {
        var s = buildString {
            for (c in w.lowercase()) if (c !in '\u064B'..'\u065F') append(c)
        }
        if (s.startsWith("ال") && s.length > 4) s = s.substring(2)
        return s
    }

    /** إيموجي مطابقة للكلمة: تطابق تام، أو بداية كلمة مفتاحية إذا كتب المستخدم 4 أحرف فأكثر */
    fun find(word: String, max: Int = 1): List<String> {
        val k = norm(word)
        if (k.length < 3) return emptyList()
        exact[k]?.let { return it.distinct().take(max) }
        if (k.length < 4) return emptyList()
        val out = LinkedHashSet<String>()
        for ((key, list) in exact) {
            if (key.startsWith(k)) out.addAll(list)
            if (out.size >= max) break
        }
        return out.take(max)
    }
}
