package com.example.mykeyboard

import android.annotation.SuppressLint
import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextView

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MyKeyboardService : InputMethodService() {

    private enum class ShiftState { OFF, ONE, LOCK }

    private lateinit var dictionary: SimpleDictionary
    private lateinit var feedback: FeedbackHelper
    private val handler = Handler(Looper.getMainLooper())

    private var mode = Mode.ENGLISH
    private var lastLetterMode = Mode.ENGLISH
    private var shift = ShiftState.OFF
    private var lastShiftTap = 0L

    /** الكلمة الجاري كتابتها (تظهر مسطّرة في الحقل حتى تكتمل) */
    private val composing = StringBuilder()
    private var suggestionsEnabled = true

    private var suggestionBar: LinearLayout? = null
    private var keysContainer: LinearLayout? = null

    private var popup: PopupWindow? = null
    private var popupText: TextView? = null

    private var repeatAction: (() -> Unit)? = null
    private val repeatRunnable = object : Runnable {
        override fun run() {
            repeatAction?.invoke()
            handler.postDelayed(this, 50)
        }
    }

    private val isArabic: Boolean get() = lastLetterMode == Mode.ARABIC

    // ------------------------------------------------------------------ دورة الحياة

    override fun onCreate() {
        super.onCreate()
        dictionary = SimpleDictionary(this)
        feedback = FeedbackHelper(this)
        VoiceBridge.listener = { text ->
            // ننتظر قليلاً حتى يعود الحقل للتركيز بعد إغلاق نافذة التعرف
            handler.postDelayed({ currentInputConnection?.commitText("$text ", 1) }, 300)
        }
    }

    override fun onDestroy() {
        VoiceBridge.listener = null
        handler.removeCallbacksAndMessages(null)
        popup?.dismiss()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR // ترتيب الحروف ثابت حتى لو كان النظام عربياً
        root.setBackgroundColor(color(R.color.keyboard_bg))
        root.setPadding(dp(3), 0, dp(3), dp(6))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val mic = TextView(this)
        mic.text = "🎤"
        mic.textSize = 20f
        mic.gravity = Gravity.CENTER
        mic.contentDescription = "Voice input"
        mic.setOnClickListener { startVoice() }
        top.addView(mic, LinearLayout.LayoutParams(dp(48), MATCH))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        suggestionBar = bar
        top.addView(bar, LinearLayout.LayoutParams(0, MATCH, 1f))
        root.addView(top, LinearLayout.LayoutParams(MATCH, dp(44)))

        val keys = LinearLayout(this)
        keys.orientation = LinearLayout.VERTICAL
        keysContainer = keys
        root.addView(keys, LinearLayout.LayoutParams(MATCH, WRAP))

        renderKeys()
        updateSuggestions()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        composing.clear()
        suggestionsEnabled = computeSuggestionsEnabled(info)
        if (!restarting) {
            val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
            mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) {
                Mode.SYMBOLS1
            } else {
                lastLetterMode
            }
            shift = ShiftState.OFF
        }
        renderKeys()
        updateSuggestions()
        updateAutoCaps()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        stopRepeat()
        hidePreview()
        composing.clear()
    }

    /** إذا حرّك المستخدم المؤشر يدوياً نُنهي الكلمة الحالية */
    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (composing.isNotEmpty() && (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            composing.clear()
            currentInputConnection?.finishComposingText()
            updateSuggestions()
        }
    }

    private fun computeSuggestionsEnabled(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return false
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        if ((t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) return false
        val v = t and InputType.TYPE_MASK_VARIATION
        return v !in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_URI,
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        )
    }

    // ------------------------------------------------------------------ بناء الأزرار

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = getColor(id)

    private fun currentRows(): List<List<Key>> = when (mode) {
        Mode.ENGLISH -> KeyboardLayouts.english.map { row ->
            row.map { if (shift != ShiftState.OFF) Key(it.label.uppercase()) else it }
        }
        Mode.ARABIC -> if (shift != ShiftState.OFF) {
            listOf(KeyboardLayouts.arabicMarks, KeyboardLayouts.arabic[1], KeyboardLayouts.arabic[2])
        } else {
            KeyboardLayouts.arabic
        }
        Mode.SYMBOLS1 -> KeyboardLayouts.symbols1
        Mode.SYMBOLS2 -> KeyboardLayouts.symbols2
        Mode.EMOJI -> emptyList()
    }

    private fun newRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        return row
    }

    private fun addSpacer(row: LinearLayout, weight: Float) {
        row.addView(Space(this), LinearLayout.LayoutParams(0, dp(46), weight))
    }

    private fun renderKeys() {
        val container = keysContainer ?: return
        container.removeAllViews()
        if (mode == Mode.EMOJI) {
            renderEmoji(container)
            return
        }

        val rows = currentRows()
        val target = rows.maxOf { it.size }.toFloat()

        rows.forEachIndexed { index, keys ->
            val row = newRow()
            val side = (target - keys.size) / 2f
            if (index < 2) {
                if (side > 0f) addSpacer(row, side)
                keys.forEach { addCharKey(row, it) }
                if (side > 0f) addSpacer(row, side)
            } else {
                addLeftSpecial(row, side)
                keys.forEach { addCharKey(row, it) }
                addKey(row, "⌫", side, special = true, repeat = true, sound = FeedbackType.DELETE) { onDelete() }
            }
            container.addView(row)
        }

        // الصف السفلي
        val letters = mode == Mode.ENGLISH || mode == Mode.ARABIC
        val bottom = newRow()
        addKey(bottom, if (letters) "123" else if (isArabic) "أ ب ج" else "ABC", 1.5f, special = true) {
            setMode(if (letters) Mode.SYMBOLS1 else lastLetterMode)
        }
        addKey(bottom, if (isArabic) "EN" else "ع", 1f, special = true) { switchLanguage() }
        addKey(bottom, "😊", 1f, special = true) {
            finishComposing()
            setMode(Mode.EMOJI)
        }
        addKey(bottom, if (isArabic) "العربية" else "English", 4f, textSize = 14f, sound = FeedbackType.SPACE) { onSpace() }
        addCharKey(bottom, Key("."))
        addKey(bottom, "↵", 1.5f, special = true, sound = FeedbackType.RETURN) { onEnter() }
        container.addView(bottom)
    }

    private fun addLeftSpecial(row: LinearLayout, weight: Float) {
        when (mode) {
            Mode.ENGLISH, Mode.ARABIC -> addKey(
                row, if (shift == ShiftState.LOCK) "⇪" else "⇧", weight,
                special = true, active = shift != ShiftState.OFF
            ) { onShift() }
            Mode.SYMBOLS1 -> addKey(row, "=\\<", weight, special = true) { setMode(Mode.SYMBOLS2) }
            else -> addKey(row, "123", weight, special = true) { setMode(Mode.SYMBOLS1) }
        }
    }

    private fun addCharKey(row: LinearLayout, key: Key) {
        addKey(row, key.label, 1f, preview = key.label) { typeText(key.text) }
    }

    /**
     * يضيف زراً. الحرف يُكتب عند رفع الإصبع (ACTION_UP) والفقاعة تظهر عند اللمس.
     * زر repeat (الحذف) يكرر الفعل أثناء الضغط المطوّل.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun addKey(
        row: LinearLayout,
        label: String,
        weight: Float,
        special: Boolean = false,
        active: Boolean = false,
        preview: String? = null,
        repeat: Boolean = false,
        textSize: Float = if (special) 16f else 20f,
        sound: FeedbackType = FeedbackType.STANDARD,
        action: () -> Unit
    ) {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = textSize
        tv.gravity = Gravity.CENTER
        tv.maxLines = 1
        tv.contentDescription = label
        tv.setTextColor(color(R.color.key_text))
        tv.setBackgroundResource(
            when {
                active -> R.drawable.key_active_bg
                special -> R.drawable.key_special_bg
                else -> R.drawable.key_bg
            }
        )

        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true
                    feedback.press(sound)
                    if (preview != null) showPreview(v, preview)
                    if (repeat) {
                        action()
                        startRepeat(action)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false
                    hidePreview()
                    stopRepeat()
                    val inside = e.x >= 0 && e.x <= v.width && e.y >= 0 && e.y <= v.height
                    if (!repeat && inside) action()
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    hidePreview()
                    stopRepeat()
                }
            }
            true
        }

        val lp = LinearLayout.LayoutParams(0, dp(46), weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        row.addView(tv, lp)
    }

    private fun renderEmoji(container: LinearLayout) {
        val cell = (resources.displayMetrics.widthPixels - dp(6)) / 8
        val grid = GridLayout(this)
        grid.columnCount = 8
        for (e in KeyboardLayouts.emojis) {
            val tv = TextView(this)
            tv.text = e
            tv.textSize = 24f
            tv.gravity = Gravity.CENTER
            tv.setOnClickListener {
                feedback.press(FeedbackType.STANDARD)
                finishComposing()
                currentInputConnection?.commitText(e, 1)
            }
            val lp = GridLayout.LayoutParams()
            lp.width = cell
            lp.height = dp(46)
            grid.addView(tv, lp)
        }
        val scroll = ScrollView(this)
        scroll.addView(grid)
        container.addView(scroll, LinearLayout.LayoutParams(MATCH, dp(190)))

        val bottom = newRow()
        addKey(bottom, if (isArabic) "أ ب ج" else "ABC", 2f, special = true) { setMode(lastLetterMode) }
        addKey(bottom, if (isArabic) "العربية" else "English", 5f, textSize = 14f, sound = FeedbackType.SPACE) { onSpace() }
        addKey(bottom, "⌫", 2f, special = true, repeat = true, sound = FeedbackType.DELETE) { onDelete() }
        container.addView(bottom)
    }

    // ------------------------------------------------------------------ الفقاعة المنبثقة

    private fun showPreview(anchor: View, label: String) {
        try {
            if (popup == null) {
                val v = layoutInflater.inflate(R.layout.popup_preview, null)
                popupText = v.findViewById<TextView>(R.id.popup_text)
                val p = PopupWindow(v, dp(56), dp(68), false)
                p.isClippingEnabled = false
                p.isTouchable = false
                popup = p
            }
            val p = popup ?: return
            popupText?.text = label
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            val x = loc[0] + anchor.width / 2 - dp(28)
            val y = loc[1] - dp(68) - dp(4)
            if (p.isShowing) p.update(x, y, -1, -1)
            else p.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
        } catch (e: Exception) {
            // لا نريد أن يتعطل الكيبورد بسبب الفقاعة
        }
    }

    private fun hidePreview() {
        popup?.dismiss()
    }

    // ------------------------------------------------------------------ الحذف المتكرر

    private fun startRepeat(action: () -> Unit) {
        repeatAction = action
        handler.postDelayed(repeatRunnable, 400)
    }

    private fun stopRepeat() {
        handler.removeCallbacks(repeatRunnable)
        repeatAction = null
    }

    // ------------------------------------------------------------------ منطق الكتابة

    private fun isWordChar(c: Char): Boolean =
        Character.isLetter(c) ||
            Character.getType(c) == Character.NON_SPACING_MARK.toInt() ||
            (c == '\'' && composing.isNotEmpty())

    private fun typeText(text: String) {
        val ic = currentInputConnection ?: return
        if (suggestionsEnabled && isWordChar(text.first())) {
            composing.append(text)
            ic.setComposingText(composing, 1)
            updateSuggestions()
        } else {
            finishComposing()
            ic.commitText(text, 1)
        }
        if (shift == ShiftState.ONE) {
            shift = ShiftState.OFF
            renderKeys()
        }
    }

    /** ينهي الكلمة الحالية ويحفظها في قاموس المستخدم */
    private fun finishComposing() {
        if (composing.isEmpty()) return
        dictionary.learn(composing.toString(), isArabic)
        currentInputConnection?.finishComposingText()
        composing.clear()
        updateSuggestions()
    }

    private fun onDelete() {
        val ic = currentInputConnection ?: return
        if (composing.isNotEmpty()) {
            composing.deleteCharAt(composing.length - 1)
            if (composing.isEmpty()) ic.commitText("", 1) else ic.setComposingText(composing, 1)
            updateSuggestions()
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) // يحذف الإيموجي المركّب كاملاً
            updateAutoCaps()
        }
    }

    private fun onSpace() {
        val ic = currentInputConnection ?: return
        finishComposing()
        ic.commitText(" ", 1)
        updateAutoCaps()
    }

    private fun onEnter() {
        val ic = currentInputConnection ?: return
        finishComposing()
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateAutoCaps()
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        shift = when {
            shift == ShiftState.LOCK -> ShiftState.OFF
            shift == ShiftState.ONE && now - lastShiftTap < 400 -> ShiftState.LOCK // نقرة مزدوجة = Caps Lock
            shift == ShiftState.ONE -> ShiftState.OFF
            else -> ShiftState.ONE
        }
        lastShiftTap = now
        renderKeys()
    }

    private fun updateAutoCaps() {
        if (mode != Mode.ENGLISH || shift == ShiftState.LOCK) return
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo ?: return
        val newShift = if (ic.getCursorCapsMode(info.inputType) != 0) ShiftState.ONE else ShiftState.OFF
        if (newShift != shift) {
            shift = newShift
            renderKeys()
        }
    }

    private fun setMode(m: Mode) {
        mode = m
        renderKeys()
    }

    private fun switchLanguage() {
        finishComposing()
        lastLetterMode = if (isArabic) Mode.ENGLISH else Mode.ARABIC
        mode = lastLetterMode
        shift = ShiftState.OFF
        renderKeys()
        updateSuggestions()
        updateAutoCaps()
    }

    // ------------------------------------------------------------------ الاقتراحات

    private fun updateSuggestions() {
        val bar = suggestionBar ?: return
        bar.removeAllViews()
        val list = if (suggestionsEnabled && composing.isNotEmpty()) {
            dictionary.suggest(composing.toString(), isArabic)
        } else {
            emptyList()
        }
        for (i in 0 until 3) {
            val word = list.getOrNull(i)
            val tv = TextView(this)
            tv.gravity = Gravity.CENTER
            tv.textSize = 17f
            tv.maxLines = 1
            tv.setTextColor(color(R.color.key_text))
            if (word != null) {
                tv.text = word
                tv.setOnClickListener { acceptSuggestion(word) }
            }
            bar.addView(tv, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
    }

    private fun acceptSuggestion(word: String) {
        val ic = currentInputConnection ?: return
        ic.commitText("$word ", 1) // يستبدل الكلمة المسطّرة بالكامل
        dictionary.learn(word, isArabic)
        composing.clear()
        updateSuggestions()
        updateAutoCaps()
    }

    // ------------------------------------------------------------------ الإدخال الصوتي

    private fun startVoice() {
        finishComposing()
        val intent = Intent(this, VoiceInputActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(VoiceInputActivity.EXTRA_LANGUAGE, if (isArabic) "ar-SA" else "en-US")
        startActivity(intent)
    }
}
