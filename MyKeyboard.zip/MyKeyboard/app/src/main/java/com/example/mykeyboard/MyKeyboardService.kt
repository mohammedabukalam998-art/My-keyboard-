package com.example.mykeyboard

import android.annotation.SuppressLint
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.text.TextUtils
import android.view.inputmethod.InputConnection
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextView

private enum class Swipe { NONE, CURSOR, DELETE_WORD }

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MyKeyboardService : InputMethodService() {

    private enum class ShiftState { OFF, ONE, LOCK }

    private lateinit var dictionary: SimpleDictionary
    private lateinit var feedback: FeedbackHelper
    private lateinit var theme: KeyboardTheme
    private val handler = Handler(Looper.getMainLooper())

    private var mode = Mode.ENGLISH
    private var lastLetterMode = Mode.ENGLISH
    private var shift = ShiftState.OFF
    private var lastShiftTap = 0L
    private var lastKeyTime = 0L // آخر وقت ضغط فيه المستخدم مفتاحاً (لتمييز تحريك المؤشر اليدوي)
    private var emojiCategory = 1 // 0 = الأخيرة، 1.. = الفئات

    // فرانكو عربي / الحافظة / الاختصارات
    private lateinit var franco: FrancoArabic
    private lateinit var clipStore: ClipboardStore
    private lateinit var shortcutStore: ShortcutStore
    private lateinit var clipboard: ClipboardManager
    private var francoOn = false
    private var easternDigits = false
    private lateinit var nextWords: NextWordPredictor
    private var francoChip: TextView? = null
    private var isPasswordField = false
    private var lastClipText: String? = null
    private var lastClipTime = 0L
    private var shortcuts: Map<String, String> = emptyMap()
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { onClipChanged() }

    private class Slot(val text: String, val bold: Boolean = false, val onClick: () -> Unit)

    // الضغط المطوّل (رموز بديلة)
    private var pendingLongPress: Runnable? = null
    private var altPopup: PopupWindow? = null
    private var altActive = false
    private var altItems: List<String> = emptyList()
    private var altViews: List<TextView> = emptyList()
    private var altSelected = 0
    private var altLeft = 0
    private var altItemW = 1

    /** الكلمة الجاري كتابتها (تظهر مسطّرة في الحقل حتى تكتمل) */
    private val composing = StringBuilder()
    private var suggestionsEnabled = true

    private var suggestionBar: LinearLayout? = null
    private var keysContainer: LinearLayout? = null

    private var popup: PopupWindow? = null
    private var popupText: TextView? = null

    private var repeatAction: (() -> Unit)? = null
    private val repeatRunnable = object : Runnable {
        override fun run() {
            lastKeyTime = SystemClock.uptimeMillis()
            repeatAction?.invoke()
            handler.postDelayed(this, 50)
        }
    }

    private val isArabic: Boolean get() = lastLetterMode == Mode.ARABIC

    // ------------------------------------------------------------------ دورة الحياة

    override fun onCreate() {
        super.onCreate()
        dictionary = SimpleDictionary(this)
        feedback = FeedbackHelper(this)
        theme = Themes.resolve(this)
        val sp = getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE)
        lastLetterMode = if (sp.getString(FeedbackHelper.KEY_LANG, "en") == "ar") Mode.ARABIC else Mode.ENGLISH
        mode = lastLetterMode
        francoOn = sp.getBoolean("franco", false)
        franco = FrancoArabic(dictionary)
        nextWords = NextWordPredictor(this)
        clipStore = ClipboardStore(this)
        shortcutStore = ShortcutStore(this)
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.addPrimaryClipChangedListener(clipListener)
        VoiceBridge.listener = { text ->
            // ننتظر قليلاً حتى يعود الحقل للتركيز بعد إغلاق نافذة التعرف
            handler.postDelayed({
                lastKeyTime = SystemClock.uptimeMillis()
                currentInputConnection?.commitText("$text ", 1)
            }, 300)
        }
    }

    override fun onDestroy() {
        VoiceBridge.listener = null
        clipboard.removePrimaryClipChangedListener(clipListener)
        handler.removeCallbacksAndMessages(null)
        popup?.dismiss()
        altPopup?.dismiss()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        theme = Themes.resolve(this)
        hideAlternates()
        popup?.dismiss()
        popup = null
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR // ترتيب الحروف ثابت حتى لو كان النظام عربياً
        root.setBackgroundColor(theme.bg)
        root.setPadding(dp(3), 0, dp(3), dp(6))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val mic = TextView(this)
        mic.text = "🎤"
        mic.textSize = 20f
        mic.gravity = Gravity.CENTER
        mic.contentDescription = "Voice input"
        mic.setOnClickListener { startVoice() }
        top.addView(mic, LinearLayout.LayoutParams(dp(44), MATCH))

        val clipBtn = TextView(this)
        clipBtn.text = "📋"
        clipBtn.textSize = 20f
        clipBtn.gravity = Gravity.CENTER
        clipBtn.contentDescription = "Clipboard"
        clipBtn.setOnClickListener {
            finishComposing()
            setMode(if (mode == Mode.CLIPBOARD) lastLetterMode else Mode.CLIPBOARD)
        }
        top.addView(clipBtn, LinearLayout.LayoutParams(dp(44), MATCH))

        val chip = TextView(this)
        chip.text = "فرانكو"
        chip.textSize = 12f
        chip.gravity = Gravity.CENTER
        chip.setTextColor(theme.text)
        chip.setOnClickListener { toggleFranco() }
        francoChip = chip
        top.addView(chip, LinearLayout.LayoutParams(dp(50), MATCH))
        refreshChip()

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        suggestionBar = bar
        top.addView(bar, LinearLayout.LayoutParams(0, MATCH, 1f))
        root.addView(top, LinearLayout.LayoutParams(MATCH, dp(44)))

        val keys = LinearLayout(this)
        keys.orientation = LinearLayout.VERTICAL
        keysContainer = keys
        root.addView(keys, LinearLayout.LayoutParams(MATCH, WRAP))

        renderKeys()
        updateSuggestions()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // إذا غيّر المستخدم الثيم من التطبيق نعيد بناء الواجهة
        if (Themes.resolve(this) != theme) setInputView(onCreateInputView())
        dictionary.refreshIfNeeded()
        composing.clear()
        suggestionsEnabled = computeSuggestionsEnabled(info)
        isPasswordField = computePasswordField(info)
        shortcuts = shortcutStore.getAll()
        easternDigits = getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE).getBoolean("eastern_digits", false)
        if (!restarting) {
            val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
            mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) {
                Mode.SYMBOLS1
            } else {
                lastLetterMode
            }
            shift = ShiftState.OFF
        }
        if (!restarting) autoSwitchLanguage(info, fromCursor = false)
        renderKeys()
        updateSuggestions()
        updateAutoCaps()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        stopRepeat()
        cancelLongPress()
        hideAlternates()
        hidePreview()
        composing.clear()
    }

    /** إذا حرّك المستخدم المؤشر يدوياً نُنهي الكلمة الحالية */
    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (composing.isNotEmpty() && (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            composing.clear()
            currentInputConnection?.finishComposingText()
            updateSuggestions()
        } else if (composing.isEmpty() && newSelStart == newSelEnd && newSelStart != oldSelStart &&
            SystemClock.uptimeMillis() - lastKeyTime > 500
        ) {
            // المستخدم حرّك المؤشر يدوياً: نختار اللغة حسب النص المجاور
            autoSwitchLanguage(currentInputEditorInfo, fromCursor = true)
        }
    }

    private fun computePasswordField(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return (cls == InputType.TYPE_CLASS_TEXT && (
            v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }

    private fun computeSuggestionsEnabled(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return false
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        if ((t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) return false
        val v = t and InputType.TYPE_MASK_VARIATION
        return v !in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_URI,
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        )
    }

    // ------------------------------------------------------------------ بناء الأزرار

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = getColor(id)

    private fun eastern(rows: List<List<Key>>): List<List<Key>> =
        if (!easternDigits) rows else rows.map { r ->
            r.map { k ->
                if (k.text.length == 1 && k.text[0] in '0'..'9') Key(('\u0660' + (k.text[0] - '0')).toString()) else k
            }
        }

    private fun keyBackground(fill: Int): StateListDrawable {
        fun shape(c: Int) = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(c)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(theme.pressed))
            addState(intArrayOf(), shape(fill))
        }
    }

    private fun currentRows(): List<List<Key>> = when (mode) {
        Mode.ENGLISH -> {
            val letters = KeyboardLayouts.english.map { row ->
                row.map { if (shift != ShiftState.OFF) Key(it.label.uppercase()) else it }
            }
            // في وضع الفرانكو نضيف صف الأرقام لأن 3 و 7 و 5 و 9 حروف
            if (francoOn) listOf(KeyboardLayouts.digits[0]) + letters else letters
        }
        Mode.ARABIC -> if (shift != ShiftState.OFF) {
            listOf(KeyboardLayouts.arabicMarks, KeyboardLayouts.arabic[1], KeyboardLayouts.arabic[2])
        } else {
            KeyboardLayouts.arabic
        }
        Mode.SYMBOLS1 -> eastern(KeyboardLayouts.symbols1)
        Mode.SYMBOLS2 -> eastern(KeyboardLayouts.symbols2)
        Mode.EMOJI, Mode.CLIPBOARD -> emptyList()
    }

    private fun newRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        return row
    }

    private fun addSpacer(row: LinearLayout, weight: Float) {
        row.addView(Space(this), LinearLayout.LayoutParams(0, dp(46), weight))
    }

    private fun renderKeys() {
        val container = keysContainer ?: return
        container.removeAllViews()
        refreshChip()
        if (mode == Mode.EMOJI) {
            renderEmoji(container)
            return
        }
        if (mode == Mode.CLIPBOARD) {
            renderClipboard(container)
            return
        }

        val rows = currentRows()
        val target = rows.maxOf { it.size }.toFloat()

        rows.forEachIndexed { index, keys ->
            val row = newRow()
            val side = (target - keys.size) / 2f
            if (index < rows.lastIndex) {
                if (side > 0f) addSpacer(row, side)
                keys.forEach { addCharKey(row, it) }
                if (side > 0f) addSpacer(row, side)
            } else {
                addLeftSpecial(row, side)
                keys.forEach { addCharKey(row, it) }
                addKey(row, "⌫", side, special = true, repeat = true, sound = FeedbackType.DELETE, swipe = Swipe.DELETE_WORD) { onDelete() }
            }
            container.addView(row)
        }

        // الصف السفلي
        val letters = mode == Mode.ENGLISH || mode == Mode.ARABIC
        val bottom = newRow()
        addKey(bottom, if (letters) "123" else if (isArabic) "أ ب ج" else "ABC", 1.5f, special = true) {
            setMode(if (letters) Mode.SYMBOLS1 else lastLetterMode)
        }
        addKey(bottom, if (isArabic) "EN" else "ع", 1f, special = true) { switchLanguage() }
        addKey(bottom, "😊", 1f, special = true) {
            finishComposing()
            openEmoji()
        }
        addKey(bottom, if (isArabic) "العربية" else "English", 4f, textSize = 14f, sound = FeedbackType.SPACE, swipe = Swipe.CURSOR) { onSpace() }
        addCharKey(bottom, Key("."))
        addKey(bottom, "↵", 1.5f, special = true, sound = FeedbackType.RETURN) { onEnter() }
        container.addView(bottom)
    }

    private fun addLeftSpecial(row: LinearLayout, weight: Float) {
        when (mode) {
            Mode.ENGLISH, Mode.ARABIC -> addKey(
                row, if (shift == ShiftState.LOCK) "⇪" else "⇧", weight,
                special = true, active = shift != ShiftState.OFF
            ) { onShift() }
            Mode.SYMBOLS1 -> addKey(row, "=\\<", weight, special = true) { setMode(Mode.SYMBOLS2) }
            else -> addKey(row, "123", weight, special = true) { setMode(Mode.SYMBOLS1) }
        }
    }

    private fun addCharKey(row: LinearLayout, key: Key) {
        val base = key.text.lowercase()
        var alts = KeyboardLayouts.alternatesFor(base, isArabic)
        if (alts != null && key.text != base) alts = alts.map { it.uppercase() }
        addKey(row, key.label, 1f, preview = key.label, alternates = alts) { typeText(key.text) }
    }

    /**
     * يضيف زراً. الحرف يُكتب عند رفع الإصبع (ACTION_UP) والفقاعة تظهر عند اللمس.
     * زر repeat (الحذف) يكرر الفعل أثناء الضغط المطوّل.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun addKey(
        row: LinearLayout,
        label: String,
        weight: Float,
        special: Boolean = false,
        active: Boolean = false,
        preview: String? = null,
        repeat: Boolean = false,
        alternates: List<String>? = null,
        textSize: Float = if (special) 16f else 20f,
        sound: FeedbackType = FeedbackType.STANDARD,
        swipe: Swipe = Swipe.NONE,
        action: () -> Unit
    ) {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = textSize
        tv.gravity = Gravity.CENTER
        tv.maxLines = 1
        tv.contentDescription = label
        tv.setTextColor(theme.text)
        tv.background = keyBackground(
            when {
                active -> theme.active
                special -> theme.special
                else -> theme.key
            }
        )

        var swipeAnchor = 0f
        var swiped = false
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastKeyTime = SystemClock.uptimeMillis()
                    v.isPressed = true
                    swipeAnchor = e.rawX
                    swiped = false
                    feedback.press(sound)
                    if (preview != null) showPreview(v, preview)
                    if (repeat) {
                        action()
                        startRepeat(action)
                    }
                    val alts = alternates
                    if (alts != null && alts.isNotEmpty()) {
                        val downX = e.rawX
                        val r = Runnable {
                            hidePreview()
                            showAlternates(v, alts, downX)
                        }
                        pendingLongPress = r
                        handler.postDelayed(r, 400)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (altActive) {
                        updateAltSelection(e.rawX)
                    } else if (swipe == Swipe.CURSOR) {
                        // سحب على المسافة: يحرّك المؤشر خطوة لكل 14dp
                        val step = dp(14)
                        val n = ((e.rawX - swipeAnchor) / step).toInt()
                        if (n != 0) {
                            if (!swiped) {
                                swiped = true
                                finishComposing()
                            }
                            lastKeyTime = SystemClock.uptimeMillis()
                            feedback.tick()
                            val code = if (n > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                            for (j in 0 until Math.abs(n)) sendDownUpKeyEvents(code)
                            swipeAnchor += n * step
                        }
                    } else if (swipe == Swipe.DELETE_WORD) {
                        // سحب الحذف لليسار: يمسح كلمة لكل 48dp
                        val step = dp(48)
                        val n = ((swipeAnchor - e.rawX) / step).toInt()
                        if (n > 0) {
                            swiped = true
                            stopRepeat()
                            lastKeyTime = SystemClock.uptimeMillis()
                            feedback.tick()
                            for (j in 0 until n) deleteWordBefore()
                            swipeAnchor -= n * step
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    lastKeyTime = SystemClock.uptimeMillis()
                    v.isPressed = false
                    cancelLongPress()
                    if (altActive) {
                        val chosen = altItems.getOrNull(altSelected)
                        hideAlternates()
                        if (chosen != null) typeText(chosen)
                    } else {
                        hidePreview()
                        stopRepeat()
                        val inside = e.x >= 0 && e.x <= v.width && e.y >= 0 && e.y <= v.height
                        if (!repeat && inside && !swiped) action()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    cancelLongPress()
                    hideAlternates()
                    hidePreview()
                    stopRepeat()
                }
            }
            true
        }

        val lp = LinearLayout.LayoutParams(0, dp(46), weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        row.addView(tv, lp)
    }

    private fun recentEmojis(): List<String> =
        getSharedPreferences("emoji_recent", MODE_PRIVATE)
            .getString("list", "").orEmpty().split(" ").filter { it.isNotEmpty() }

    private fun saveRecent(e: String) {
        val list = (listOf(e) + recentEmojis().filter { it != e }).take(24)
        getSharedPreferences("emoji_recent", MODE_PRIVATE)
            .edit().putString("list", list.joinToString(" ")).apply()
    }

    private fun openEmoji() {
        emojiCategory = if (recentEmojis().isNotEmpty()) 0 else 1
        setMode(Mode.EMOJI)
    }

    private fun renderEmoji(container: LinearLayout) {
        val cats = KeyboardLayouts.emojiCategories

        // شريط الفئات
        val tabs = newRow()
        val icons = listOf("🕘") + cats.map { it.icon }
        icons.forEachIndexed { i, icon ->
            val tv = TextView(this)
            tv.text = icon
            tv.textSize = 20f
            tv.gravity = Gravity.CENTER
            if (i == emojiCategory) tv.background = keyBackground(theme.active)
            tv.setOnClickListener {
                emojiCategory = i
                renderKeys()
            }
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            tabs.addView(tv, lp)
        }
        container.addView(tabs)

        val list = if (emojiCategory == 0) recentEmojis() else cats[emojiCategory - 1].emojis

        if (list.isEmpty()) {
            val hint = TextView(this)
            hint.text = "لا توجد رموز حديثة بعد"
            hint.gravity = Gravity.CENTER
            hint.setTextColor(theme.text)
            container.addView(hint, LinearLayout.LayoutParams(MATCH, dp(170)))
        } else {
            val cell = (resources.displayMetrics.widthPixels - dp(6)) / 8
            val grid = GridLayout(this)
            grid.columnCount = 8
            for (e in list) {
                val tv = TextView(this)
                tv.text = e
                tv.textSize = 24f
                tv.gravity = Gravity.CENTER
                tv.setOnClickListener {
                    lastKeyTime = SystemClock.uptimeMillis()
                    feedback.press(FeedbackType.STANDARD)
                    finishComposing()
                    currentInputConnection?.commitText(e, 1)
                    saveRecent(e)
                }
                val lp = GridLayout.LayoutParams()
                lp.width = cell
                lp.height = dp(46)
                grid.addView(tv, lp)
            }
            val scroll = ScrollView(this)
            scroll.addView(grid)
            container.addView(scroll, LinearLayout.LayoutParams(MATCH, dp(170)))
        }

        val bottom = newRow()
        addKey(bottom, if (isArabic) "أ ب ج" else "ABC", 2f, special = true) { setMode(lastLetterMode) }
        addKey(bottom, if (isArabic) "العربية" else "English", 5f, textSize = 14f, sound = FeedbackType.SPACE, swipe = Swipe.CURSOR) { onSpace() }
        addKey(bottom, "⌫", 2f, special = true, repeat = true, sound = FeedbackType.DELETE, swipe = Swipe.DELETE_WORD) { onDelete() }
        container.addView(bottom)
    }

    // ------------------------------------------------------------------ الضغط المطوّل

    private fun cancelLongPress() {
        pendingLongPress?.let { handler.removeCallbacks(it) }
        pendingLongPress = null
    }

    private fun showAlternates(anchor: View, items: List<String>, rawX: Float) {
        try {
            val itemW = dp(40)
            val itemH = dp(48)
            val pad = dp(4)

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.layoutDirection = View.LAYOUT_DIRECTION_LTR
            row.setPadding(pad, pad, pad, pad)
            val bgShape = GradientDrawable()
            bgShape.cornerRadius = dp(12).toFloat()
            bgShape.setColor(theme.popup)
            bgShape.setStroke(dp(1), 0x33000000)
            row.background = bgShape

            val views = ArrayList<TextView>()
            for (item in items) {
                val tv = TextView(this)
                tv.text = item
                tv.textSize = 22f
                tv.gravity = Gravity.CENTER
                tv.setTextColor(theme.text)
                row.addView(tv, LinearLayout.LayoutParams(itemW, itemH))
                views.add(tv)
            }

            val totalW = itemW * items.size + pad * 2
            val totalH = itemH + pad * 2
            val screenW = resources.displayMetrics.widthPixels
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            val x = (loc[0] + anchor.width / 2 - totalW / 2).coerceIn(0, maxOf(0, screenW - totalW))
            val y = loc[1] - totalH - dp(8)

            altPopup?.dismiss()
            val p = PopupWindow(row, totalW, totalH, false)
            p.isClippingEnabled = false
            p.isTouchable = false
            p.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)

            altPopup = p
            altItems = items
            altViews = views
            altLeft = x + pad
            altItemW = itemW
            altActive = true
            altSelected = ((rawX - altLeft) / altItemW).toInt().coerceIn(0, items.size - 1)
            highlightAlt()
        } catch (e: Exception) {
            hideAlternates()
        }
    }

    private fun updateAltSelection(rawX: Float) {
        if (altItems.isEmpty()) return
        val idx = ((rawX - altLeft) / altItemW).toInt().coerceIn(0, altItems.size - 1)
        if (idx != altSelected) {
            altSelected = idx
            highlightAlt()
        }
    }

    private fun highlightAlt() {
        altViews.forEachIndexed { i, tv ->
            if (i == altSelected) {
                val g = GradientDrawable()
                g.cornerRadius = dp(8).toFloat()
                g.setColor(theme.active)
                tv.background = g
            } else {
                tv.background = null
            }
        }
    }

    private fun hideAlternates() {
        altPopup?.dismiss()
        altPopup = null
        altActive = false
        altItems = emptyList()
        altViews = emptyList()
    }

    // ------------------------------------------------------------------ الفقاعة المنبثقة

    private fun showPreview(anchor: View, label: String) {
        try {
            if (popup == null) {
                val v = layoutInflater.inflate(R.layout.popup_preview, null)
                popupText = v.findViewById<TextView>(R.id.popup_text)
                popupText?.setTextColor(theme.text)
                popupText?.background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(theme.popup)
                    setStroke(dp(1), 0x33000000)
                }
                val p = PopupWindow(v, dp(56), dp(68), false)
                p.isClippingEnabled = false
                p.isTouchable = false
                popup = p
            }
            val p = popup ?: return
            popupText?.text = label
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            val x = loc[0] + anchor.width / 2 - dp(28)
            val y = loc[1] - dp(68) - dp(4)
            if (p.isShowing) p.update(x, y, -1, -1)
            else p.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
        } catch (e: Exception) {
            // لا نريد أن يتعطل الكيبورد بسبب الفقاعة
        }
    }

    private fun hidePreview() {
        popup?.dismiss()
    }

    // ------------------------------------------------------------------ الحذف المتكرر

    private fun startRepeat(action: () -> Unit) {
        repeatAction = action
        handler.postDelayed(repeatRunnable, 400)
    }

    private fun stopRepeat() {
        handler.removeCallbacks(repeatRunnable)
        repeatAction = null
    }

    // ------------------------------------------------------------------ منطق الكتابة

    private fun isWordChar(c: Char): Boolean =
        Character.isLetter(c) ||
            Character.getType(c) == Character.NON_SPACING_MARK.toInt() ||
            (c == '\'' && composing.isNotEmpty()) ||
            (francoActive() && c in "2356789")

    private fun typeText(text: String) {
        val ic = currentInputConnection ?: return
        if (suggestionsEnabled && isWordChar(text.first())) {
            composing.append(text)
            ic.setComposingText(composing, 1)
            updateSuggestions()
        } else {
            finishComposing()
            ic.commitText(text, 1)
            updateSuggestions()
        }
        if (shift == ShiftState.ONE) {
            shift = ShiftState.OFF
            renderKeys()
        }
    }

    /** ينهي الكلمة الحالية ويحفظها في قاموس المستخدم */
    private fun finishComposing() {
        if (composing.isEmpty()) return
        learnBigram(composing.toString())
        dictionary.learn(composing.toString(), isArabic)
        currentInputConnection?.finishComposingText()
        composing.clear()
        updateSuggestions()
    }

    private fun onDelete() {
        val ic = currentInputConnection ?: return
        if (composing.isNotEmpty()) {
            composing.deleteCharAt(composing.length - 1)
            if (composing.isEmpty()) ic.commitText("", 1) else ic.setComposingText(composing, 1)
            updateSuggestions()
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) // يحذف الإيموجي المركّب كاملاً
            updateSuggestions()
            updateAutoCaps()
        }
    }

    private fun onSpace() {
        val ic = currentInputConnection ?: return
        // اختصار نصي؟ (نفحصه قبل إنهاء الكلمة حتى لا يُحفظ الاختصار في القاموس)
        if (!isPasswordField && shortcuts.isNotEmpty() && tryExpandShortcut(ic)) {
            composing.clear()
            updateSuggestions()
            updateAutoCaps()
            return
        }
        finishComposing()
        ic.commitText(" ", 1)
        updateSuggestions()
        updateAutoCaps()
    }

    private fun tryExpandShortcut(ic: InputConnection): Boolean {
        val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: return false
        val token = before.takeLastWhile { !it.isWhitespace() }
        if (token.isEmpty()) return false
        val expansion = shortcuts[token] ?: return false
        ic.finishComposingText()
        ic.deleteSurroundingText(token.length, 0)
        ic.commitText("$expansion ", 1)
        return true
    }

    private fun onEnter() {
        val ic = currentInputConnection ?: return
        finishComposing()
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateSuggestions()
        updateAutoCaps()
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        shift = when {
            shift == ShiftState.LOCK -> ShiftState.OFF
            shift == ShiftState.ONE && now - lastShiftTap < 400 -> ShiftState.LOCK // نقرة مزدوجة = Caps Lock
            shift == ShiftState.ONE -> ShiftState.OFF
            else -> ShiftState.ONE
        }
        lastShiftTap = now
        renderKeys()
    }

    private fun updateAutoCaps() {
        if (mode != Mode.ENGLISH || shift == ShiftState.LOCK) return
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo ?: return
        val newShift = if (ic.getCursorCapsMode(info.inputType) != 0) ShiftState.ONE else ShiftState.OFF
        if (newShift != shift) {
            shift = newShift
            renderKeys()
        }
    }

    private fun setMode(m: Mode) {
        mode = m
        renderKeys()
    }

    private fun switchLanguage() {
        finishComposing()
        lastLetterMode = if (isArabic) Mode.ENGLISH else Mode.ARABIC
        getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE).edit()
            .putString(FeedbackHelper.KEY_LANG, if (isArabic) "ar" else "en").apply()
        mode = lastLetterMode
        shift = ShiftState.OFF
        renderKeys()
        updateSuggestions()
        updateAutoCaps()
    }

    // ------------------------------------------------------------------ التبديل التلقائي للغة

    private fun isAutoLangEnabled() = getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE)
        .getBoolean(FeedbackHelper.KEY_AUTO_LANG, true)

    /**
     * عند فتح حقل جديد: نوع الحقل (بريد/رابط) ثم لغة تلميح الحقل ثم النص السابق للمؤشر ثم اللغة المفضلة.
     * عند تحريك المؤشر يدوياً: النص المجاور فقط.
     */
    private fun autoSwitchLanguage(info: EditorInfo?, fromCursor: Boolean) {
        if (!isAutoLangEnabled() || composing.isNotEmpty()) return
        val target = if (fromCursor) {
            detectLanguageFromContext()
        } else {
            languageForField(info) ?: detectLanguageFromContext() ?: preferredLanguage()
        } ?: return
        if (target == lastLetterMode) return

        lastLetterMode = target
        if (mode == Mode.ENGLISH || mode == Mode.ARABIC) {
            mode = target
            shift = ShiftState.OFF
        }
        if (mode != Mode.EMOJI && mode != Mode.CLIPBOARD) {
            renderKeys()
            updateSuggestions()
            updateAutoCaps()
        }
    }

    private fun preferredLanguage(): Mode =
        if (getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE)
                .getString(FeedbackHelper.KEY_LANG, "en") == "ar") Mode.ARABIC else Mode.ENGLISH

    private fun languageForField(info: EditorInfo?): Mode? {
        val t = info?.inputType ?: return null
        if ((t and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT) {
            val v = t and InputType.TYPE_MASK_VARIATION
            if (v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
                v == InputType.TYPE_TEXT_VARIATION_URI
            ) return Mode.ENGLISH
        }
        val locales = info.hintLocales
        if (locales != null && !locales.isEmpty()) {
            return when (locales.get(0).language) {
                "ar" -> Mode.ARABIC
                "en" -> Mode.ENGLISH
                else -> null
            }
        }
        return null
    }

    /** آخر حرف قبل المؤشر: عربي أم لاتيني؟ */
    private fun detectLanguageFromContext(): Mode? {
        val before = currentInputConnection?.getTextBeforeCursor(20, 0) ?: return null
        for (i in before.length - 1 downTo 0) {
            val c = before[i]
            if (!Character.isLetter(c)) continue
            return when {
                c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' ||
                    c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF' -> Mode.ARABIC
                c.code < 0x250 -> Mode.ENGLISH
                else -> null
            }
        }
        return null
    }

    // ------------------------------------------------------------------ فرانكو عربي

    private fun francoActive() = francoOn && mode == Mode.ENGLISH && suggestionsEnabled

    private fun toggleFranco() {
        francoOn = !francoOn
        getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE).edit().putBoolean("franco", francoOn).apply()
        renderKeys()
        updateSuggestions()
    }

    private fun refreshChip() {
        val chip = francoChip ?: return
        chip.visibility = if (isArabic) View.GONE else View.VISIBLE
        chip.background = if (francoOn) keyBackground(theme.active) else null
    }

    // ------------------------------------------------------------------ الحافظة

    private fun onClipChanged() {
        try {
            if (isPasswordField) return
            val clip = clipboard.primaryClip ?: return
            if (clip.itemCount == 0) return
            val desc = clip.description
            if (desc.extras?.getBoolean("android.content.extra.IS_SENSITIVE") == true) return
            if (!desc.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) &&
                !desc.hasMimeType(ClipDescription.MIMETYPE_TEXT_HTML)
            ) return
            val text = clip.getItemAt(0).coerceToText(this).toString().trim()
            if (text.isEmpty() || text.length > 2000) return
            clipStore.add(text)
            lastClipText = text
            lastClipTime = SystemClock.uptimeMillis()
            updateSuggestions()
        } catch (e: Exception) {
            // بعض الأجهزة تمنع قراءة الحافظة أحياناً
        }
    }

    private fun pasteText(text: String) {
        lastKeyTime = SystemClock.uptimeMillis()
        finishComposing()
        currentInputConnection?.commitText(text, 1)
    }

    private fun renderClipboard(container: LinearLayout) {
        val items = clipStore.load().sortedByDescending { it.pinned }

        val header = newRow()
        val title = TextView(this)
        title.text = "الحافظة"
        title.textSize = 16f
        title.setTextColor(theme.text)
        title.gravity = Gravity.CENTER_VERTICAL
        title.setPadding(dp(12), 0, 0, 0)
        header.addView(title, LinearLayout.LayoutParams(0, dp(40), 4f))
        addKey(header, "🗑", 1f, special = true) {
            clipStore.clearUnpinned()
            renderKeys()
        }
        container.addView(header)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        if (items.isEmpty()) {
            val hint = TextView(this)
            hint.text = "لا يوجد شيء منسوخ بعد"
            hint.gravity = Gravity.CENTER
            hint.setTextColor(theme.text)
            list.addView(hint, LinearLayout.LayoutParams(MATCH, dp(120)))
        }
        for (item in items) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = keyBackground(theme.key)

            val text = TextView(this)
            text.text = item.text.replace('\n', ' ')
            text.maxLines = 2
            text.ellipsize = TextUtils.TruncateAt.END
            text.textSize = 14f
            text.setTextColor(theme.text)
            text.setPadding(dp(10), dp(8), dp(10), dp(8))
            text.setOnClickListener {
                feedback.press(FeedbackType.STANDARD)
                pasteText(item.text)
                setMode(lastLetterMode)
            }
            row.addView(text, LinearLayout.LayoutParams(0, WRAP, 1f))

            val pin = TextView(this)
            pin.text = "📌"
            pin.textSize = 18f
            pin.gravity = Gravity.CENTER
            pin.alpha = if (item.pinned) 1f else 0.35f
            pin.setOnClickListener {
                clipStore.togglePin(item.text)
                renderKeys()
            }
            row.addView(pin, LinearLayout.LayoutParams(dp(40), dp(40)))

            val del = TextView(this)
            del.text = "✕"
            del.textSize = 16f
            del.gravity = Gravity.CENTER
            del.setTextColor(theme.text)
            del.setOnClickListener {
                clipStore.delete(item.text)
                renderKeys()
            }
            row.addView(del, LinearLayout.LayoutParams(dp(40), dp(40)))

            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.setMargins(dp(3), dp(2), dp(3), dp(2))
            list.addView(row, lp)
        }
        val scroll = ScrollView(this)
        scroll.addView(list)
        container.addView(scroll, LinearLayout.LayoutParams(MATCH, dp(176)))

        val bottom = newRow()
        addKey(bottom, if (isArabic) "أ ب ج" else "ABC", 2f, special = true) { setMode(lastLetterMode) }
        addKey(bottom, if (isArabic) "العربية" else "English", 5f, textSize = 14f, sound = FeedbackType.SPACE, swipe = Swipe.CURSOR) { onSpace() }
        addKey(bottom, "⌫", 2f, special = true, repeat = true, sound = FeedbackType.DELETE, swipe = Swipe.DELETE_WORD) { onDelete() }
        container.addView(bottom)
    }

    // ------------------------------------------------------------------ الكلمة التالية وحذف الكلمات

    private fun previousWord(): String? {
        val before = currentInputConnection?.getTextBeforeCursor(60, 0)?.toString() ?: return null
        return NextWordPredictor.wordBefore(before)
    }

    /** يسجّل أن [word] جاءت بعد الكلمة السابقة (النص قبل المؤشر بعد استبعاد الكلمة الجارية) */
    private fun learnBigram(word: String) {
        if (isPasswordField || !suggestionsEnabled) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(60, 0)?.toString() ?: return
        val ctx = if (composing.isNotEmpty() && before.length >= composing.length) before.dropLast(composing.length) else before
        val prev = NextWordPredictor.wordBefore(ctx) ?: return
        nextWords.learn(prev, word)
    }

    /** يحذف الكلمة السابقة للمؤشر (مع المسافات التي بعدها) */
    private fun deleteWordBefore() {
        val ic = currentInputConnection ?: return
        finishComposing()
        val before = ic.getTextBeforeCursor(50, 0)?.toString() ?: return
        var i = before.length
        while (i > 0 && before[i - 1].isWhitespace()) i--
        while (i > 0 && !before[i - 1].isWhitespace()) i--
        val n = before.length - i
        if (n > 0) ic.deleteSurroundingText(n, 0)
        updateSuggestions()
        updateAutoCaps()
    }

    // ------------------------------------------------------------------ الاقتراحات

    private fun updateSuggestions() {
        val bar = suggestionBar ?: return
        bar.removeAllViews()

        val slots = ArrayList<Slot>()
        if (suggestionsEnabled && composing.isNotEmpty()) {
            val typed = composing.toString()
            if (francoActive()) {
                for (w in franco.candidates(typed, 2)) slots.add(Slot(w, true) { acceptSuggestion(w) })
            }
            for (w in dictionary.suggest(typed, isArabic)) {
                if (slots.size < 3 && slots.none { it.text == w }) slots.add(Slot(w) { acceptSuggestion(w) })
            }
        } else if (composing.isEmpty() && !isPasswordField) {
            // ما نُسخ قبل أقل من دقيقة يظهر كاقتراح لصقه
            val clip = lastClipText
            if (clip != null && SystemClock.uptimeMillis() - lastClipTime < 60_000) {
                slots.add(Slot("📋 " + clip.replace('\n', ' ').take(14)) {
                    pasteText(clip)
                    lastClipText = null
                    updateSuggestions()
                })
            }
            // الكلمات المتوقعة بعد الكلمة السابقة
            if (suggestionsEnabled) {
                val prev = previousWord()
                if (prev != null) {
                    for (w in nextWords.predict(prev, 3)) {
                        val shown = if (shift != ShiftState.OFF && !isArabic) w.replaceFirstChar { it.uppercase() } else w
                        if (slots.size < 3 && slots.none { it.text == shown }) {
                            slots.add(Slot(shown) { acceptSuggestion(shown) })
                        }
                    }
                }
            }
        }

        for (i in 0 until 3) {
            val slot = slots.getOrNull(i)
            val tv = TextView(this)
            tv.gravity = Gravity.CENTER
            tv.textSize = 17f
            tv.maxLines = 1
            tv.setTextColor(theme.text)
            if (slot != null) {
                tv.text = slot.text
                if (slot.bold) tv.setTypeface(null, Typeface.BOLD)
                tv.setOnClickListener { slot.onClick() }
            }
            bar.addView(tv, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
    }

    private fun acceptSuggestion(word: String) {
        val ic = currentInputConnection ?: return
        lastKeyTime = SystemClock.uptimeMillis()
        learnBigram(word)
        ic.commitText("$word ", 1) // يستبدل الكلمة المسطّرة بالكامل
        dictionary.learn(word, word.first() in '\u0600'..'\u06FF')
        composing.clear()
        updateSuggestions()
        updateAutoCaps()
    }

    // ------------------------------------------------------------------ الإدخال الصوتي

    private fun startVoice() {
        finishComposing()
        val intent = Intent(this, VoiceInputActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(VoiceInputActivity.EXTRA_LANGUAGE, if (isArabic) "ar-SA" else "en-US")
        startActivity(intent)
    }
}
