package com.example.mykeyboard

import android.annotation.SuppressLint
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PointF
import android.graphics.Typeface
import android.text.TextUtils
import android.view.inputmethod.InputConnection
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextView

private enum class Swipe { NONE, CURSOR, DELETE_WORD }

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private const val AI_FIX = "Fix spelling, grammar and punctuation. Keep the same language, meaning and tone."
private const val AI_REPHRASE = "Rephrase the text to be clearer and more natural, keeping the same language and meaning."
private const val AI_FORMAL = "Rewrite the text in a more formal, professional tone, keeping the same language and meaning."
private const val AI_FRIENDLY = "Rewrite the text in a friendlier, more casual tone, keeping the same language and meaning."
private const val AI_SHORT = "Make the text shorter and more concise, keeping the key meaning and the same language."
private const val AI_TRANSLATE = "Translate the text: if it is mainly Arabic translate it to English, otherwise translate it to Arabic."

class MyKeyboardService : InputMethodService() {

    private enum class ShiftState { OFF, ONE, LOCK }

    private lateinit var dictionary: SimpleDictionary
    private lateinit var feedback: FeedbackHelper
    private lateinit var theme: KeyboardTheme
    private val handler = Handler(Looper.getMainLooper())

    private var mode = Mode.ENGLISH
    private var lastLetterMode = Mode.ENGLISH
    private var shift = ShiftState.OFF
    private var lastShiftTap = 0L
    private var lastKeyTime = 0L // آخر وقت ضغط فيه المستخدم مفتاحاً (لتمييز تحريك المؤشر اليدوي)
    private var emojiCategory = 1 // 0 = الأخيرة، 1.. = الفئات

    // فرانكو عربي / الحافظة / الاختصارات
    private lateinit var franco: FrancoArabic
    private lateinit var clipStore: ClipboardStore
    private lateinit var shortcutStore: ShortcutStore
    private lateinit var clipboard: ClipboardManager
    private var francoOn = false
    private var easternDigits = false
    private lateinit var nextWords: NextWordPredictor
    private var francoChip: TextView? = null
    private var isPasswordField = false
    private var lastClipText: String? = null
    private var lastClipTime = 0L
    private var shortcuts: Map<String, String> = emptyMap()
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { onClipChanged() }

    private class Slot(val text: String, val bold: Boolean = false, val onClick: () -> Unit)
    private class AutoFix(val original: String, val fixed: String, val trailing: String)

    private lateinit var glideDecoder: GlideDecoder
    private var glideLayout: GlideLayout? = null
    private var glideAlternatives: List<String>? = null
    private var glideWord: String? = null
    private var lastFix: AutoFix? = null

    // الضغط المطوّل (رموز بديلة)
    private var pendingLongPress: Runnable? = null
    private var altPopup: PopupWindow? = null
    private var altActive = false
    private var altItems: List<String> = emptyList()
    private var altViews: List<TextView> = emptyList()
    private var altSelected = 0
    private var altLeft = 0
    private var altItemW = 1

    /** الكلمة الجاري كتابتها (تظهر مسطّرة في الحقل حتى تكتمل) */
    private val composing = StringBuilder()
    private var suggestionsEnabled = true

    private var suggestionBar: LinearLayout? = null
    private var keysContainer: LinearLayout? = null

    private var popup: PopupWindow? = null
    private var popupText: TextView? = null

    private var repeatAction: (() -> Unit)? = null
    private val repeatRunnable = object : Runnable {
        override fun run() {
            lastKeyTime = SystemClock.uptimeMillis()
            repeatAction?.invoke()
            handler.postDelayed(this, 50)
        }
    }

    private val isArabic: Boolean get() = lastLetterMode == Mode.ARABIC

    // ------------------------------------------------------------------ دورة الحياة

    override fun onCreate() {
        super.onCreate()
        dictionary = SimpleDictionary(this)
        feedback = FeedbackHelper(this)
        theme = Themes.resolve(this)
        keyShape = KeyShapes.read(this)
        loadKeyColors()
        val sp = getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE)
        lastLetterMode = if (sp.getString(FeedbackHelper.KEY_LANG, "en") == "ar") Mode.ARABIC else Mode.ENGLISH
        mode = lastLetterMode
        francoOn = sp.getBoolean("franco", false)
        franco = FrancoArabic(dictionary)
        glideDecoder = GlideDecoder(dictionary)
        nextWords = NextWordPredictor(this)
        clipStore = ClipboardStore(this)
        shortcutStore = ShortcutStore(this)
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.addPrimaryClipChangedListener(clipListener)
        VoiceBridge.listener = { text ->
            // ننتظر قليلاً حتى يعود الحقل للتركيز بعد إغلاق نافذة التعرف
            handler.postDelayed({
                lastKeyTime = SystemClock.uptimeMillis()
                currentInputConnection?.commitText("$text ", 1)
            }, 300)
        }
    }

    override fun onDestroy() {
        VoiceBridge.listener = null
        clipboard.removePrimaryClipChangedListener(clipListener)
        handler.removeCallbacksAndMessages(null)
        popup?.dismiss()
        altPopup?.dismiss()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        theme = Themes.resolve(this)
        keyShape = KeyShapes.read(this)
        loadKeyColors()
        hideAlternates()
        popup?.dismiss()
        popup = null
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR // ترتيب الحروف ثابت حتى لو كان النظام عربياً
        root.setBackgroundColor(theme.bg)
        root.setPadding(dp(3), 0, dp(3), dp(6))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val mic = TextView(this)
        mic.text = "🎤"
        mic.textSize = 20f
        mic.gravity = Gravity.CENTER
        mic.contentDescription = "Voice input"
        mic.setOnClickListener { startVoice() }
        top.addView(mic, LinearLayout.LayoutParams(dp(40), MATCH))

        val clipBtn = TextView(this)
        clipBtn.text = "📋"
        clipBtn.textSize = 20f
        clipBtn.gravity = Gravity.CENTER
        clipBtn.contentDescription = "Clipboard"
        clipBtn.setOnClickListener {
            finishComposing()
            setMode(if (mode == Mode.CLIPBOARD) lastLetterMode else Mode.CLIPBOARD)
        }
        top.addView(clipBtn, LinearLayout.LayoutParams(dp(40), MATCH))

        val toolsBtn = TextView(this)
        toolsBtn.text = "🛠"
        toolsBtn.textSize = 20f
        toolsBtn.gravity = Gravity.CENTER
        toolsBtn.contentDescription = "Tools"
        toolsBtn.setOnClickListener {
            finishComposing()
            setMode(if (mode == Mode.TOOLS || mode == Mode.AI) lastLetterMode else Mode.TOOLS)
        }
        top.addView(toolsBtn, LinearLayout.LayoutParams(dp(40), MATCH))

        val chip = TextView(this)
        chip.text = "فرانكو"
        chip.textSize = 12f
        chip.gravity = Gravity.CENTER
        chip.setTextColor(theme.text)
        chip.setOnClickListener { toggleFranco() }
        francoChip = chip
        top.addView(chip, LinearLayout.LayoutParams(dp(46), MATCH))
        refreshChip()

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        suggestionBar = bar
        top.addView(bar, LinearLayout.LayoutParams(0, MATCH, 1f))
        root.addView(top, LinearLayout.LayoutParams(MATCH, dp(44)))

        val keys = GlideLayout(this)
        keys.orientation = LinearLayout.VERTICAL
        keys.trailColor = theme.active
        keys.glideEnabled = isGlideEnabled()
        keys.canStart = { glideAllowed() }
        keys.onGlide = { path, gk -> onGlide(path, gk) }
        glideLayout = keys
        keysContainer = keys
        root.addView(keys, LinearLayout.LayoutParams(MATCH, WRAP))

        renderKeys()
        updateSuggestions()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        // إذا غيّر المستخدم الثيم من التطبيق نعيد بناء الواجهة
        if (Themes.resolve(this) != theme || KeyShapes.read(this) != keyShape ||
            KeyColors.signature(this) != colorSig
        ) setInputView(onCreateInputView())
        dictionary.refreshIfNeeded()
        glideLayout?.glideEnabled = isGlideEnabled()
        composing.clear()
        suggestionsEnabled = computeSuggestionsEnabled(info)
        isPasswordField = computePasswordField(info)
        shortcuts = shortcutStore.getAll()
        easternDigits = getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE).getBoolean("eastern_digits", false)
        if (!restarting) {
            val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
            mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) {
                Mode.SYMBOLS1
            } else {
                lastLetterMode
            }
            shift = ShiftState.OFF
        }
        if (!restarting) autoSwitchLanguage(info, fromCursor = false)
        renderKeys()
        updateSuggestions()
        updateAutoCaps()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        stopRepeat()
        cancelLongPress()
        hideAlternates()
        hidePreview()
        composing.clear()
    }

    /** إذا حرّك المستخدم المؤشر يدوياً نُنهي الكلمة الحالية */
    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int,
        newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (composing.isNotEmpty() && (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)) {
            composing.clear()
            currentInputConnection?.finishComposingText()
            updateSuggestions()
        } else if (composing.isEmpty() && newSelStart == newSelEnd && newSelStart != oldSelStart &&
            SystemClock.uptimeMillis() - lastKeyTime > 500
        ) {
            // المستخدم حرّك المؤشر يدوياً: نختار اللغة حسب النص المجاور
            autoSwitchLanguage(currentInputEditorInfo, fromCursor = true)
        }
    }

    private fun computePasswordField(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return (cls == InputType.TYPE_CLASS_TEXT && (
            v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }

    private fun computeSuggestionsEnabled(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return false
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        if ((t and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) return false
        val v = t and InputType.TYPE_MASK_VARIATION
        return v !in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_URI,
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        )
    }

    // ------------------------------------------------------------------ بناء الأزرار

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(id: Int) = getColor(id)

    private fun eastern(rows: List<List<Key>>): List<List<Key>> =
        if (!easternDigits) rows else rows.map { r ->
            r.map { k ->
                if (k.text.length == 1 && k.text[0] in '0'..'9') Key(('\u0660' + (k.text[0] - '0')).toString()) else k
            }
        }

    private var keyShape = "round"
    private var keyColors: Map<String, Int> = emptyMap()
    private var rainbowOn = false
    private var colorSig = ""

    private fun loadKeyColors() {
        keyColors = KeyColors.load(this)
        rainbowOn = KeyColors.rainbow(this)
        colorSig = KeyColors.signature(this)
    }

    private fun keyBackground(fill: Int, narrow: Boolean = false, pressed: Int = theme.pressed): StateListDrawable =
        KeyShapes.background(keyShape, fill, pressed, narrow, dp(8).toFloat())

    /** المفاتيح الدائرية أقل ارتفاعاً حتى تبقى الدوائر متقاربة */
    private fun keyHeight() = if (keyShape == "circle") dp(40) else dp(46)

    private fun currentRows(): List<List<Key>> = when (mode) {
        Mode.ENGLISH -> {
            val letters = KeyboardLayouts.english.map { row ->
                row.map { if (shift != ShiftState.OFF) Key(it.label.uppercase()) else it }
            }
            // في وضع الفرانكو نضيف صف الأرقام لأن 3 و 7 و 5 و 9 حروف
            if (francoOn) listOf(KeyboardLayouts.digits[0]) + letters else letters
        }
        Mode.ARABIC -> if (shift != ShiftState.OFF) {
            listOf(KeyboardLayouts.arabicMarks, KeyboardLayouts.arabic[1], KeyboardLayouts.arabic[2])
        } else {
            KeyboardLayouts.arabic
        }
        Mode.SYMBOLS1 -> eastern(KeyboardLayouts.symbols1)
        Mode.SYMBOLS2 -> eastern(KeyboardLayouts.symbols2)
        Mode.EMOJI, Mode.CLIPBOARD, Mode.TOOLS, Mode.AI -> emptyList()
    }

    private fun newRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        return row
    }

    private fun addSpacer(row: LinearLayout, weight: Float) {
        row.addView(Space(this), LinearLayout.LayoutParams(0, keyHeight(), weight))
    }

    private fun renderKeys() {
        val container = keysContainer ?: return
        container.removeAllViews()
        refreshChip()
        if (mode == Mode.EMOJI) {
            renderEmoji(container)
            return
        }
        if (mode == Mode.CLIPBOARD) {
            renderClipboard(container)
            return
        }
        if (mode == Mode.TOOLS) {
            renderTools(container)
            return
        }
        if (mode == Mode.AI) {
            renderAi(container)
            return
        }

        val rows = currentRows()
        val target = rows.maxOf { it.size }.toFloat()

        rows.forEachIndexed { index, keys ->
            val row = newRow()
            val side = (target - keys.size) / 2f
            if (index < rows.lastIndex) {
                if (side > 0f) addSpacer(row, side)
                keys.forEachIndexed { i, k -> addCharKey(row, k, (side + i + 0.5f) / target, index) }
                if (side > 0f) addSpacer(row, side)
            } else {
                addLeftSpecial(row, side)
                keys.forEachIndexed { i, k -> addCharKey(row, k, (side + i + 0.5f) / target, index) }
                addKey(row, "⌫", side, special = true, repeat = true, sound = FeedbackType.DELETE, swipe = Swipe.DELETE_WORD, colorId = "delete") { onDelete() }
            }
            container.addView(row)
        }

        // الصف السفلي
        val letters = mode == Mode.ENGLISH || mode == Mode.ARABIC
        val bottom = newRow()
        addKey(bottom, if (letters) "123" else if (isArabic) "أ ب ج" else "ABC", 1.5f, special = true, colorId = "sym") {
            setMode(if (letters) Mode.SYMBOLS1 else lastLetterMode)
        }
        addKey(bottom, if (isArabic) "EN" else "ع", 1f, special = true, colorId = "lang") { switchLanguage() }
        addKey(bottom, "😊", 1f, special = true, colorId = "emoji") {
            finishComposing()
            openEmoji()
        }
        addKey(bottom, if (isArabic) "العربية" else "English", 4f, textSize = 14f, sound = FeedbackType.SPACE, swipe = Swipe.CURSOR, colorId = "space") { onSpace() }
        addCharKey(bottom, Key("."), 0.82f, 3)
        addKey(bottom, "↵", 1.5f, special = true, sound = FeedbackType.RETURN, colorId = "enter") { onEnter() }
        container.addView(bottom)
    }

    private fun addLeftSpecial(row: LinearLayout, weight: Float) {
        when (mode) {
            Mode.ENGLISH, Mode.ARABIC -> addKey(
                row, if (shift == ShiftState.LOCK) "⇪" else "⇧", weight,
                special = true, active = shift != ShiftState.OFF, colorId = "shift"
            ) { onShift() }
            Mode.SYMBOLS1 -> addKey(row, "=\\<", weight, special = true, colorId = "sym") { setMode(Mode.SYMBOLS2) }
            else -> addKey(row, "123", weight, special = true, colorId = "sym") { setMode(Mode.SYMBOLS1) }
        }
    }

    private fun addCharKey(row: LinearLayout, key: Key, hueFrac: Float = -1f, hueRow: Int = 0) {
        val base = key.text.lowercase()
        var alts = KeyboardLayouts.alternatesFor(base, isArabic)
        if (alts != null && key.text != base) alts = alts.map { it.uppercase() }
        // الأحرف فقط (بدون أرقام وعلامات وتشكيل وتطويل) تشارك في الكتابة بالسحب
        val glideChar = if ((mode == Mode.ENGLISH || mode == Mode.ARABIC) &&
            key.text.length == 1 && key.text[0].isLetter() && key.text[0] != '\u0640'
        ) key.text else null
        addKey(row, key.label, 1f, preview = key.label, alternates = alts, glideChar = glideChar,
            colorId = base, hueFrac = hueFrac, hueRow = hueRow) { typeText(key.text) }
    }

    /**
     * يضيف زراً. الحرف يُكتب عند رفع الإصبع (ACTION_UP) والفقاعة تظهر عند اللمس.
     * زر repeat (الحذف) يكرر الفعل أثناء الضغط المطوّل.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun addKey(
        row: LinearLayout,
        label: String,
        weight: Float,
        special: Boolean = false,
        active: Boolean = false,
        preview: String? = null,
        repeat: Boolean = false,
        alternates: List<String>? = null,
        textSize: Float = if (special) 16f else 20f,
        sound: FeedbackType = FeedbackType.STANDARD,
        swipe: Swipe = Swipe.NONE,
        glideChar: String? = null,
        colorId: String? = null,
        hueFrac: Float = -1f,
        hueRow: Int = 0,
        action: () -> Unit
    ) {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = textSize
        tv.gravity = Gravity.CENTER
        tv.maxLines = 1
        tv.contentDescription = label
        if (glideChar != null) tv.tag = glideChar
        val baseFill = when {
            active -> theme.active
            special -> theme.special
            else -> theme.key
        }
        // اللون اليدوي ثم قوس قزح (للأحرف فقط) ثم لون الثيم
        var custom: Int? = null
        if (!active) {
            custom = colorId?.let { keyColors[it] }
            if (custom == null && rainbowOn && !special && hueFrac >= 0f) {
                custom = KeyColors.rainbowColor(hueFrac, hueRow, KeyColors.isDark(theme.key))
            }
        }
        val fill = custom ?: baseFill
        tv.setTextColor(if (custom != null) KeyColors.readableText(fill) else theme.text)
        tv.background = if (custom != null) {
            keyBackground(fill, narrow = weight <= 1.25f, pressed = KeyColors.pressedFor(fill))
        } else {
            keyBackground(fill, narrow = weight <= 1.25f)
        }

        var swipeAnchor = 0f
        var swiped = false
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastKeyTime = SystemClock.uptimeMillis()
                    v.isPressed = true
                    swipeAnchor = e.rawX
                    swiped = false
                    feedback.press(sound)
                    if (preview != null) showPreview(v, preview)
                    if (repeat) {
                        action()
                        startRepeat(action)
                    }
                    val alts = alternates
                    if (alts != null && alts.isNotEmpty()) {
                        val downX = e.rawX
                        val r = Runnable {
                            hidePreview()
                            showAlternates(v, alts, downX)
                        }
                        pendingLongPress = r
                        handler.postDelayed(r, 400)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (altActive) {
                        updateAltSelection(e.rawX)
                    } else if (swipe == Swipe.CURSOR) {
                        // سحب على المسافة: يحرّك المؤشر خطوة لكل 14dp
                        val step = dp(14)
                        val n = ((e.rawX - swipeAnchor) / step).toInt()
                        if (n != 0) {
                            if (!swiped) {
                                swiped = true
                                finishComposing()
                            }
                            lastKeyTime = SystemClock.uptimeMillis()
                            feedback.tick()
                            val code = if (n > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                            for (j in 0 until Math.abs(n)) sendDownUpKeyEvents(code)
                            swipeAnchor += n * step
                        }
                    } else if (swipe == Swipe.DELETE_WORD) {
                        // سحب الحذف لليسار: يمسح كلمة لكل 48dp
                        val step = dp(48)
                        val n = ((swipeAnchor - e.rawX) / step).toInt()
                        if (n > 0) {
                            swiped = true
                            stopRepeat()
                            lastKeyTime = SystemClock.uptimeMillis()
                            feedback.tick()
                            for (j in 0 until n) deleteWordBefore()
                            swipeAnchor -= n * step
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    lastKeyTime = SystemClock.uptimeMillis()
                    v.isPressed = false
                    cancelLongPress()
                    if (altActive) {
                        val chosen = altItems.getOrNull(altSelected)
                        hideAlternates()
                        if (chosen != null) typeText(chosen)
                    } else {
                        hidePreview()
                        stopRepeat()
                        val inside = e.x >= 0 && e.x <= v.width && e.y >= 0 && e.y <= v.height
                        if (!repeat && inside && !swiped) action()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    cancelLongPress()
                    hideAlternates()
                    hidePreview()
                    stopRepeat()
                }
            }
            true
        }

        val lp = LinearLayout.LayoutParams(0, keyHeight(), weight)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        row.addView(tv, lp)
    }

    private fun recentEmojis(): List<String> =
        getSharedPreferences("emoji_recent", MODE_PRIVATE)
            .getString("list", "").orEmpty().split(" ").filter { it.isNotEmpty() }

    private fun saveRecent(e: String) {
        val list = (listOf(e) + recentEmojis().filter { it != e }).take(24)
        getSharedPreferences("emoji_recent", MODE_PRIVATE)
            .edit().putString("list", list.joinToString(" ")).apply()
    }

    private fun openEmoji() {
        emojiCategory = if (recentEmojis().isNotEmpty()) 0 else 1
        setMode(Mode.EMOJI)
    }

    private fun renderEmoji(container: LinearLayout) {
        val cats = KeyboardLayouts.emojiCategories

        // شريط الفئات
        val tabs = newRow()
        val icons = listOf("🕘") + cats.map { it.icon }
        icons.forEachIndexed { i, icon ->
            val tv = TextView(this)
            tv.text = icon
            tv.textSize = 20f
            tv.gravity = Gravity.CENTER
            if (i == emojiCategory) tv.background = keyBackground(theme.active)
            tv.setOnClickListener {
                emojiCategory = i
                renderKeys()
            }
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            tabs.addView(tv, lp)
        }
        container.addView(tabs)

        val list = if (emojiCategory == 0) recentEmojis() else cats[emojiCategory - 1].emojis

        if (list.isEmpty()) {
            val hint = TextView(this)
            hint.text = "لا توجد رموز حديثة بعد"
            hint.gravity = Gravity.CENTER
            hint.setTextColor(theme.text)
            container.addView(hint, LinearLayout.LayoutParams(MATCH, dp(170)))
        } else {
            val cell = (resources.displayMetrics.widthPixels - dp(6)) / 8
            val grid = GridLayout(this)
            grid.columnCount = 8
            for (e in list) {
                val tv = TextView(this)
                tv.text = e
                tv.textSize = 24f
                tv.gravity = Gravity.CENTER
                tv.setOnClickListener {
                    lastKeyTime = SystemClock.uptimeMillis()
                    feedback.press(FeedbackType.STANDARD)
                    finishComposing()
                    currentInputConnection?.commitText(e, 1)
                    saveRecent(e)
                }
                val lp = GridLayout.LayoutParams()
                lp.width = cell
                lp.height = dp(46)
                grid.addView(tv, lp)
            }
            val scroll = ScrollView(this)
            scroll.addView(grid)
            container.addView(scroll, LinearLayout.LayoutParams(MATCH, dp(170)))
        }

        val bottom = newRow()
        addKey(bottom, if (isArabic) "أ ب ج" else "ABC", 2f, special = true) { setMode(lastLetterMode) }
        addKey(bottom, if (isArabic) "العربية" else "English", 5f, textSize = 14f, sound = FeedbackType.SPACE, swipe = Swipe.CURSOR) { onSpace() }
        addKey(bottom, "⌫", 2f, special = true, repeat = true, sound = FeedbackType.DELETE, swipe = Swipe.DELETE_WORD) { onDelete() }
        container.addView(bottom)
    }

    // ------------------------------------------------------------------ الضغط المطوّل

    private fun cancelLongPress() {
        pendingLongPress?.let { handler.removeCallbacks(it) }
        pendingLongPress = null
    }

    private fun showAlternates(anchor: View, items: List<String>, rawX: Float) {
        try {
            val itemW = dp(40)
            val itemH = dp(48)
            val pad = dp(4)

            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.layoutDirection = View.LAYOUT_DIRECTION_LTR
            row.setPadding(pad, pad, pad, pad)
            val bgShape = GradientDrawable()
            bgShape.cornerRadius = dp(12).toFloat()
            bgShape.setColor(theme.popup)
            bgShape.setStroke(dp(1), 0x33000000)
            row.background = bgShape

            val views = ArrayList<TextView>()
            for (item in items) {
                val tv = TextView(this)
                tv.text = item
                tv.textSize = 22f
                tv.gravity = Gravity.CENTER
                tv.setTextColor(theme.text)
                row.addView(tv, LinearLayout.LayoutParams(itemW, itemH))
                views.add(tv)
            }

            val totalW = itemW * items.size + pad * 2
            val totalH = itemH + pad * 2
            val screenW = resources.displayMetrics.widthPixels
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            val x = (loc[0] + anchor.width / 2 - totalW / 2).coerceIn(0, maxOf(0, screenW - totalW))
            val y = loc[1] - totalH - dp(8)

            altPopup?.dismiss()
            val p = PopupWindow(row, totalW, totalH, false)
            p.isClippingEnabled = false
            p.isTouchable = false
            p.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)

            altPopup = p
            altItems = items
            altViews = views
            altLeft = x + pad
            altItemW = itemW
            altActive = true
            altSelected = ((rawX - altLeft) / altItemW).toInt().coerceIn(0, items.size - 1)
            highlightAlt()
        } catch (e: Exception) {
            hideAlternates()
        }
    }

    private fun updateAltSelection(rawX: Float) {
        if (altItems.isEmpty()) return
        val idx = ((rawX - altLeft) / altItemW).toInt().coerceIn(0, altItems.size - 1)
        if (idx != altSelected) {
            altSelected = idx
            highlightAlt()
        }
    }

    private fun highlightAlt() {
        altViews.forEachIndexed { i, tv ->
            if (i == altSelected) {
                val g = GradientDrawable()
                g.cornerRadius = dp(8).toFloat()
                g.setColor(theme.active)
                tv.background = g
            } else {
                tv.background = null
            }
        }
    }

    private fun hideAlternates() {
        altPopup?.dismiss()
        altPopup = null
        altActive = false
        altItems = emptyList()
        altViews = emptyList()
    }

    // ------------------------------------------------------------------ الفقاعة المنبثقة

    private fun showPreview(anchor: View, label: String) {
        try {
            if (popup == null) {
                val v = layoutInflater.inflate(R.layout.popup_preview, null)
                popupText = v.findViewById<TextView>(R.id.popup_text)
                popupText?.setTextColor(theme.text)
                popupText?.background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(theme.popup)
                    setStroke(dp(1), 0x33000000)
                }
                val p = PopupWindow(v, dp(56), dp(68), false)
                p.isClippingEnabled = false
                p.isTouchable = false
                popup = p
            }
            val p = popup ?: return
            popupText?.text = label
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            val x = loc[0] + anchor.width / 2 - dp(28)
            val y = loc[1] - dp(68) - dp(4)
            if (p.isShowing) p.update(x, y, -1, -1)
            else p.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
        } catch (e: Exception) {
            // لا نريد أن يتعطل الكيبورد بسبب الفقاعة
        }
    }

    private fun hidePreview() {
        popup?.dismiss()
    }

    // ------------------------------------------------------------------ الحذف المتكرر

    private fun startRepeat(action: () -> Unit) {
        repeatAction = action
        handler.postDelayed(repeatRunnable, 400)
    }

    private fun stopRepeat() {
        handler.removeCallbacks(repeatRunnable)
        repeatAction = null
    }

    // ------------------------------------------------------------------ منطق الكتابة

    private fun isWordChar(c: Char): Boolean =
        Character.isLetter(c) ||
            Character.getType(c) == Character.NON_SPACING_MARK.toInt() ||
            (c == '\'' && composing.isNotEmpty()) ||
            (francoActive() && c in "2356789")

    private fun typeText(text: String) {
        val ic = currentInputConnection ?: return
        lastFix = null
        glideAlternatives = null
        if (suggestionsEnabled && isWordChar(text.first())) {
            composing.append(text)
            ic.setComposingText(composing, 1)
            updateSuggestions()
        } else {
            val corrected = composing.isNotEmpty() && text in correctTriggers && tryAutoCorrect(text)
            if (!corrected) {
                finishComposing()
                ic.commitText(text, 1)
            }
            updateSuggestions()
        }
        if (shift == ShiftState.ONE) {
            shift = ShiftState.OFF
            renderKeys()
        }
    }

    /** ينهي الكلمة الحالية ويحفظها في قاموس المستخدم */
    private fun finishComposing() {
        if (composing.isEmpty()) return
        learnBigram(composing.toString())
        dictionary.learn(composing.toString(), isArabic)
        currentInputConnection?.finishComposingText()
        composing.clear()
        updateSuggestions()
    }

    private fun onDelete() {
        val ic = currentInputConnection ?: return
        glideAlternatives = null
        if (composing.isEmpty() && undoAutoCorrect()) return
        lastFix = null
        if (composing.isNotEmpty()) {
            composing.deleteCharAt(composing.length - 1)
            if (composing.isEmpty()) ic.commitText("", 1) else ic.setComposingText(composing, 1)
            updateSuggestions()
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) // يحذف الإيموجي المركّب كاملاً
            updateSuggestions()
            updateAutoCaps()
        }
    }

    private fun onSpace() {
        val ic = currentInputConnection ?: return
        // بعد الكتابة بالسحب تُضاف المسافة تلقائياً، فنكتفي بإخفاء البدائل
        if (glideAlternatives != null && composing.isEmpty()) {
            glideAlternatives = null
            glideWord = null
            updateSuggestions()
            return
        }
        lastFix = null
        // اختصار نصي؟ (نفحصه قبل إنهاء الكلمة حتى لا يُحفظ الاختصار في القاموس)
        if (!isPasswordField && shortcuts.isNotEmpty() && tryExpandShortcut(ic)) {
            composing.clear()
            updateSuggestions()
            updateAutoCaps()
            return
        }
        if (tryAutoCorrect(" ")) {
            updateSuggestions()
            updateAutoCaps()
            return
        }
        finishComposing()
        ic.commitText(" ", 1)
        updateSuggestions()
        updateAutoCaps()
    }

    private fun tryExpandShortcut(ic: InputConnection): Boolean {
        val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: return false
        val token = before.takeLastWhile { !it.isWhitespace() }
        if (token.isEmpty()) return false
        val expansion = shortcuts[token] ?: return false
        ic.finishComposingText()
        ic.deleteSurroundingText(token.length, 0)
        ic.commitText("$expansion ", 1)
        return true
    }

    private fun onEnter() {
        val ic = currentInputConnection ?: return
        lastFix = null
        glideAlternatives = null
        finishComposing()
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnterAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateSuggestions()
        updateAutoCaps()
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        shift = when {
            shift == ShiftState.LOCK -> ShiftState.OFF
            shift == ShiftState.ONE && now - lastShiftTap < 400 -> ShiftState.LOCK // نقرة مزدوجة = Caps Lock
            shift == ShiftState.ONE -> ShiftState.OFF
            else -> ShiftState.ONE
        }
        lastShiftTap = now
        renderKeys()
    }

    private fun updateAutoCaps() {
        if (mode != Mode.ENGLISH || shift == ShiftState.LOCK) return
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo ?: return
        val newShift = if (ic.getCursorCapsMode(info.inputType) != 0) ShiftState.ONE else ShiftState.OFF
        if (newShift != shift) {
            shift = newShift
            renderKeys()
        }
    }

    private fun setMode(m: Mode) {
        mode = m
        renderKeys()
    }

    private fun switchLanguage() {
        finishComposing()
        lastLetterMode = if (isArabic) Mode.ENGLISH else Mode.ARABIC
        getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE).edit()
            .putString(FeedbackHelper.KEY_LANG, if (isArabic) "ar" else "en").apply()
        mode = lastLetterMode
        shift = ShiftState.OFF
        renderKeys()
        updateSuggestions()
        updateAutoCaps()
    }

    // ------------------------------------------------------------------ التبديل التلقائي للغة

    private fun isAutoLangEnabled() = getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE)
        .getBoolean(FeedbackHelper.KEY_AUTO_LANG, true)

    /**
     * عند فتح حقل جديد: نوع الحقل (بريد/رابط) ثم لغة تلميح الحقل ثم النص السابق للمؤشر ثم اللغة المفضلة.
     * عند تحريك المؤشر يدوياً: النص المجاور فقط.
     */
    private fun autoSwitchLanguage(info: EditorInfo?, fromCursor: Boolean) {
        if (!isAutoLangEnabled() || composing.isNotEmpty()) return
        val target = if (fromCursor) {
            detectLanguageFromContext()
        } else {
            languageForField(info) ?: detectLanguageFromContext() ?: preferredLanguage()
        } ?: return
        if (target == lastLetterMode) return

        lastLetterMode = target
        if (mode == Mode.ENGLISH || mode == Mode.ARABIC) {
            mode = target
            shift = ShiftState.OFF
        }
        if (!isPanelMode()) {
            renderKeys()
            updateSuggestions()
            updateAutoCaps()
        }
    }

    private fun preferredLanguage(): Mode =
        if (getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE)
                .getString(FeedbackHelper.KEY_LANG, "en") == "ar") Mode.ARABIC else Mode.ENGLISH

    private fun languageForField(info: EditorInfo?): Mode? {
        val t = info?.inputType ?: return null
        if ((t and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT) {
            val v = t and InputType.TYPE_MASK_VARIATION
            if (v == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
                v == InputType.TYPE_TEXT_VARIATION_URI
            ) return Mode.ENGLISH
        }
        val locales = info.hintLocales
        if (locales != null && !locales.isEmpty()) {
            return when (locales.get(0).language) {
                "ar" -> Mode.ARABIC
                "en" -> Mode.ENGLISH
                else -> null
            }
        }
        return null
    }

    /** آخر حرف قبل المؤشر: عربي أم لاتيني؟ */
    private fun detectLanguageFromContext(): Mode? {
        val before = currentInputConnection?.getTextBeforeCursor(20, 0) ?: return null
        for (i in before.length - 1 downTo 0) {
            val c = before[i]
            if (!Character.isLetter(c)) continue
            return when {
                c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' ||
                    c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF' -> Mode.ARABIC
                c.code < 0x250 -> Mode.ENGLISH
                else -> null
            }
        }
        return null
    }

    // ------------------------------------------------------------------ فرانكو عربي

    private fun francoActive() = francoOn && mode == Mode.ENGLISH && suggestionsEnabled

    private fun toggleFranco() {
        francoOn = !francoOn
        getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE).edit().putBoolean("franco", francoOn).apply()
        renderKeys()
        updateSuggestions()
    }

    private fun refreshChip() {
        val chip = francoChip ?: return
        chip.visibility = if (isArabic) View.GONE else View.VISIBLE
        chip.background = if (francoOn) keyBackground(theme.active) else null
    }

    // ------------------------------------------------------------------ الحافظة

    private fun onClipChanged() {
        try {
            if (isPasswordField) return
            val clip = clipboard.primaryClip ?: return
            if (clip.itemCount == 0) return
            val desc = clip.description
            if (desc.extras?.getBoolean("android.content.extra.IS_SENSITIVE") == true) return
            if (!desc.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) &&
                !desc.hasMimeType(ClipDescription.MIMETYPE_TEXT_HTML)
            ) return
            val text = clip.getItemAt(0).coerceToText(this).toString().trim()
            if (text.isEmpty() || text.length > 2000) return
            clipStore.add(text)
            lastClipText = text
            lastClipTime = SystemClock.uptimeMillis()
            updateSuggestions()
        } catch (e: Exception) {
            // بعض الأجهزة تمنع قراءة الحافظة أحياناً
        }
    }

    private fun pasteText(text: String) {
        lastKeyTime = SystemClock.uptimeMillis()
        finishComposing()
        currentInputConnection?.commitText(text, 1)
    }

    private fun renderClipboard(container: LinearLayout) {
        val items = clipStore.load().sortedByDescending { it.pinned }

        val header = newRow()
        val title = TextView(this)
        title.text = "الحافظة"
        title.textSize = 16f
        title.setTextColor(theme.text)
        title.gravity = Gravity.CENTER_VERTICAL
        title.setPadding(dp(12), 0, 0, 0)
        header.addView(title, LinearLayout.LayoutParams(0, dp(40), 4f))
        addKey(header, "🗑", 1f, special = true) {
            clipStore.clearUnpinned()
            renderKeys()
        }
        container.addView(header)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        if (items.isEmpty()) {
            val hint = TextView(this)
            hint.text = "لا يوجد شيء منسوخ بعد"
            hint.gravity = Gravity.CENTER
            hint.setTextColor(theme.text)
            list.addView(hint, LinearLayout.LayoutParams(MATCH, dp(120)))
        }
        for (item in items) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = keyBackground(theme.key)

            val text = TextView(this)
            text.text = item.text.replace('\n', ' ')
            text.maxLines = 2
            text.ellipsize = TextUtils.TruncateAt.END
            text.textSize = 14f
            text.setTextColor(theme.text)
            text.setPadding(dp(10), dp(8), dp(10), dp(8))
            text.setOnClickListener {
                feedback.press(FeedbackType.STANDARD)
                pasteText(item.text)
                setMode(lastLetterMode)
            }
            row.addView(text, LinearLayout.LayoutParams(0, WRAP, 1f))

            val pin = TextView(this)
            pin.text = "📌"
            pin.textSize = 18f
            pin.gravity = Gravity.CENTER
            pin.alpha = if (item.pinned) 1f else 0.35f
            pin.setOnClickListener {
                clipStore.togglePin(item.text)
                renderKeys()
            }
            row.addView(pin, LinearLayout.LayoutParams(dp(40), dp(40)))

            val del = TextView(this)
            del.text = "✕"
            del.textSize = 16f
            del.gravity = Gravity.CENTER
            del.setTextColor(theme.text)
            del.setOnClickListener {
                clipStore.delete(item.text)
                renderKeys()
            }
            row.addView(del, LinearLayout.LayoutParams(dp(40), dp(40)))

            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.setMargins(dp(3), dp(2), dp(3), dp(2))
            list.addView(row, lp)
        }
        val scroll = ScrollView(this)
        scroll.addView(list)
        container.addView(scroll, LinearLayout.LayoutParams(MATCH, dp(176)))

        val bottom = newRow()
        addKey(bottom, if (isArabic) "أ ب ج" else "ABC", 2f, special = true) { setMode(lastLetterMode) }
        addKey(bottom, if (isArabic) "العربية" else "English", 5f, textSize = 14f, sound = FeedbackType.SPACE, swipe = Swipe.CURSOR) { onSpace() }
        addKey(bottom, "⌫", 2f, special = true, repeat = true, sound = FeedbackType.DELETE, swipe = Swipe.DELETE_WORD) { onDelete() }
        container.addView(bottom)
    }

    // ------------------------------------------------------------------ الكلمة التالية وحذف الكلمات

    private fun previousWord(): String? {
        val before = currentInputConnection?.getTextBeforeCursor(60, 0)?.toString() ?: return null
        return NextWordPredictor.wordBefore(before)
    }

    /** يسجّل أن [word] جاءت بعد الكلمة السابقة (النص قبل المؤشر بعد استبعاد الكلمة الجارية) */
    private fun learnBigram(word: String) {
        if (isPasswordField || !suggestionsEnabled) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(60, 0)?.toString() ?: return
        val ctx = if (composing.isNotEmpty() && before.length >= composing.length) before.dropLast(composing.length) else before
        val prev = NextWordPredictor.wordBefore(ctx) ?: return
        nextWords.learn(prev, word)
    }

    /** يحذف الكلمة السابقة للمؤشر (مع المسافات التي بعدها) */
    private fun deleteWordBefore() {
        val ic = currentInputConnection ?: return
        finishComposing()
        val before = ic.getTextBeforeCursor(50, 0)?.toString() ?: return
        var i = before.length
        while (i > 0 && before[i - 1].isWhitespace()) i--
        while (i > 0 && !before[i - 1].isWhitespace()) i--
        val n = before.length - i
        if (n > 0) ic.deleteSurroundingText(n, 0)
        updateSuggestions()
        updateAutoCaps()
    }

    // ------------------------------------------------------------------ الاقتراحات

    private fun updateSuggestions() {
        val bar = suggestionBar ?: return
        bar.removeAllViews()

        val slots = ArrayList<Slot>()
        val ga = glideAlternatives
        if (ga != null && composing.isEmpty()) {
            ga.forEachIndexed { i, w -> if (i < 3) slots.add(Slot(w, i == 0) { replaceGlideWord(w) }) }
        } else if (suggestionsEnabled && composing.isNotEmpty()) {
            val typed = composing.toString()
            if (francoActive()) {
                for (w in franco.candidates(typed, 2)) slots.add(Slot(w, true) { acceptSuggestion(w) })
            }
            for (w in dictionary.suggest(typed, isArabic)) {
                if (slots.size < 3 && slots.none { it.text == w }) slots.add(Slot(w) { acceptSuggestion(w) })
            }
            if (!francoActive() && settings().getBoolean("emoji_suggest", true)) {
                val emoji = EmojiKeywords.find(typed, 1).firstOrNull()
                if (emoji != null) {
                    if (slots.size >= 3) slots.removeAt(slots.size - 1)
                    slots.add(Slot(emoji) { insertEmojiAfterWord(emoji) })
                }
            }
        } else if (composing.isEmpty() && !isPasswordField) {
            // ما نُسخ قبل أقل من دقيقة يظهر كاقتراح لصقه
            val clip = lastClipText
            if (clip != null && SystemClock.uptimeMillis() - lastClipTime < 60_000) {
                slots.add(Slot("📋 " + clip.replace('\n', ' ').take(14)) {
                    pasteText(clip)
                    lastClipText = null
                    updateSuggestions()
                })
            }
            // الكلمات المتوقعة بعد الكلمة السابقة
            if (suggestionsEnabled) {
                val prev = previousWord()
                if (prev != null) {
                    for (w in nextWords.predict(prev, 3)) {
                        val shown = if (shift != ShiftState.OFF && !isArabic) w.replaceFirstChar { it.uppercase() } else w
                        if (slots.size < 3 && slots.none { it.text == shown }) {
                            slots.add(Slot(shown) { acceptSuggestion(shown) })
                        }
                    }
                }
            }
        }

        for (i in 0 until 3) {
            val slot = slots.getOrNull(i)
            val tv = TextView(this)
            tv.gravity = Gravity.CENTER
            tv.textSize = 17f
            tv.maxLines = 1
            tv.setTextColor(theme.text)
            if (slot != null) {
                tv.text = slot.text
                if (slot.bold) tv.setTypeface(null, Typeface.BOLD)
                tv.setOnClickListener { slot.onClick() }
            }
            bar.addView(tv, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
    }

    private fun acceptSuggestion(word: String) {
        val ic = currentInputConnection ?: return
        lastKeyTime = SystemClock.uptimeMillis()
        lastFix = null
        glideAlternatives = null
        learnBigram(word)
        ic.commitText("$word ", 1) // يستبدل الكلمة المسطّرة بالكامل
        dictionary.learn(word, word.first() in '\u0600'..'\u06FF')
        composing.clear()
        updateSuggestions()
        updateAutoCaps()
    }

    // ------------------------------------------------------------------ التصحيح التلقائي

    private fun settings() = getSharedPreferences(FeedbackHelper.PREFS, MODE_PRIVATE)
    private fun isAutoCorrectEnabled() = settings().getBoolean("autocorrect", true)
    private fun isGlideEnabled() = settings().getBoolean("glide", true)

    private val correctTriggers = setOf(".", ",", "!", "?", ";", ":", ")", "،", "؟", "؛")

    /**
     * يصحح الكلمة الجارية (إن كانت خطأ إملائياً واضحاً) ويكتبها مع [trailing] (مسافة أو علامة ترقيم).
     * لا يصحح: الأسماء (حرف كبير وسط الجملة)، الكلمات الكبيرة كلها، ما فيه أرقام، حقول الباسورد/الروابط،
     * ولا في وضع الفرانكو. يرجع true إذا تم التصحيح.
     */
    private fun tryAutoCorrect(trailing: String): Boolean {
        if (!isAutoCorrectEnabled() || !suggestionsEnabled || isPasswordField || francoActive()) return false
        if (composing.isEmpty()) return false
        val ic = currentInputConnection ?: return false
        val typed = composing.toString()
        if (typed.any { it.isDigit() }) return false
        val arabic = typed.any { it in '\u0600'..'\u06FF' }
        if (!arabic && typed.length > 1 && typed.all { it.isUpperCase() }) return false

        val before = ic.getTextBeforeCursor(80, 0)?.toString().orEmpty()
        if (!before.endsWith(typed)) return false
        val startsUpper = typed.first().isUpperCase()
        if (startsUpper) {
            val ctx = before.dropLast(typed.length).trimEnd()
            val sentenceStart = ctx.isEmpty() || ctx.last() in ".!?؟\n"
            if (!sentenceStart) return false // غالباً اسم علم
        }

        val fix = dictionary.correct(typed, arabic) ?: return false
        val shown = if (startsUpper) fix.replaceFirstChar { it.uppercase() } else fix
        learnBigram(shown)
        ic.commitText(shown + trailing, 1)
        composing.clear()
        lastFix = if (trailing == " ") AutoFix(typed, shown, trailing) else null
        return true
    }

    /** الحذف مباشرة بعد تصحيح تلقائي يعيد الكلمة الأصلية ويتعلمها */
    private fun undoAutoCorrect(): Boolean {
        val fix = lastFix ?: return false
        lastFix = null
        val ic = currentInputConnection ?: return false
        val tail = fix.fixed + fix.trailing
        val before = ic.getTextBeforeCursor(tail.length, 0)?.toString()
        if (before != tail) return false
        ic.deleteSurroundingText(tail.length, 0)
        val arabic = fix.original.any { it in '\u0600'..'\u06FF' }
        dictionary.learn(fix.original, arabic)
        dictionary.learn(fix.original, arabic) // مرتان: تصبح كلمة معروفة ولا تُصحَّح بعد الآن
        composing.append(fix.original)
        ic.setComposingText(composing, 1)
        updateSuggestions()
        return true
    }

    // ------------------------------------------------------------------ الكتابة بالسحب

    private fun glideAllowed(): Boolean =
        (mode == Mode.ENGLISH || mode == Mode.ARABIC) && !altActive && suggestionsEnabled && !francoOn

    private fun onGlide(path: List<PointF>, keys: List<GlideKey>) {
        // ننفذ بعد انتهاء معالجة اللمس لأن الحاوية ستُعاد رسمها
        handler.post { commitGlide(path, keys) }
    }

    private fun commitGlide(path: List<PointF>, keys: List<GlideKey>) {
        val words = glideDecoder.decode(path, keys, isArabic, 3)
        if (words.isEmpty()) return
        val ic = currentInputConnection ?: return
        finishComposing()

        val upper = !isArabic && shift != ShiftState.OFF
        val lock = shift == ShiftState.LOCK
        val shown = words.map { w ->
            if (!upper) w else if (lock) w.uppercase() else w.replaceFirstChar { it.uppercase() }
        }
        if (shift == ShiftState.ONE) {
            shift = ShiftState.OFF
            renderKeys()
        }

        // إذا كان قبل المؤشر حرف ملتصق، نضيف مسافة قبل الكلمة
        val prev = ic.getTextBeforeCursor(1, 0)?.toString().orEmpty()
        if (prev.isNotEmpty() && prev.last().isLetterOrDigit()) ic.commitText(" ", 1)

        acceptSuggestion(shown[0]) // يكتب الكلمة + مسافة ويتعلم ويحدّث التوقعات
        glideWord = shown[0]
        glideAlternatives = shown
        updateSuggestions() // يعرض البدائل في شريط الاقتراحات
    }

    /** اختيار كلمة بديلة بعد الكتابة بالسحب: تستبدل الكلمة التي كُتبت للتو */
    private fun replaceGlideWord(w: String) {
        val ic = currentInputConnection ?: return
        val old = glideWord
        if (old == null || w == old) {
            glideAlternatives = null
            updateSuggestions()
            return
        }
        val before = ic.getTextBeforeCursor(old.length + 1, 0)?.toString()
        glideAlternatives = null
        glideWord = null
        if (before == "$old ") {
            ic.deleteSurroundingText(old.length + 1, 0)
            acceptSuggestion(w)
        } else {
            updateSuggestions()
        }
    }

    // ------------------------------------------------------------------ شريط الأدوات

    private fun isPanelMode() =
        mode == Mode.EMOJI || mode == Mode.CLIPBOARD || mode == Mode.TOOLS || mode == Mode.AI

    private fun editAction(id: Int) {
        lastKeyTime = SystemClock.uptimeMillis()
        finishComposing()
        currentInputConnection?.performContextMenuAction(id)
    }

    private fun sendCtrl(code: Int, withShift: Boolean = false) {
        val ic = currentInputConnection ?: return
        finishComposing()
        val now = SystemClock.uptimeMillis()
        lastKeyTime = now
        val meta = KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON or
            (if (withShift) KeyEvent.META_SHIFT_ON else 0)
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0, meta))
    }

    private var selectMode = false

    /** يحرّك المؤشر (أو يمدّ التحديد إن كان وضع "تحديد" مفعّلاً) حرفاً أو كلمة */
    private fun moveCursor(code: Int, byWord: Boolean) {
        val ic = currentInputConnection ?: return
        finishComposing()
        val now = SystemClock.uptimeMillis()
        lastKeyTime = now
        var meta = 0
        if (byWord) meta = meta or KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        if (selectMode) meta = meta or KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, code, 0, meta))
        ic.sendKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, code, 0, meta))
    }

    /** تحويل حالة أحرف النص المحدد: 0 = كبيرة، 1 = صغيرة، 2 = أول كل كلمة */
    private fun convertSelectionCase(kind: Int) {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString().orEmpty()
        if (sel.isEmpty()) return
        lastKeyTime = SystemClock.uptimeMillis()
        val out = when (kind) {
            0 -> sel.uppercase()
            1 -> sel.lowercase()
            else -> sel.split(" ").joinToString(" ") { w -> w.lowercase().replaceFirstChar { it.uppercase() } }
        }
        ic.commitText(out, 1)
    }

    private fun renderTools(container: LinearLayout) {
        val r1 = newRow()
        addKey(r1, "تحديد الكل", 1f, special = true, textSize = 13f) { editAction(android.R.id.selectAll) }
        addKey(r1, "نسخ", 1f, special = true, textSize = 13f) { editAction(android.R.id.copy) }
        addKey(r1, "قص", 1f, special = true, textSize = 13f) { editAction(android.R.id.cut) }
        addKey(r1, "لصق", 1f, special = true, textSize = 13f) { editAction(android.R.id.paste) }
        container.addView(r1)

        val r2 = newRow()
        addKey(r2, "↶ تراجع", 1f, special = true, textSize = 13f) { sendCtrl(KeyEvent.KEYCODE_Z) }
        addKey(r2, "↷ إعادة", 1f, special = true, textSize = 13f) { sendCtrl(KeyEvent.KEYCODE_Z, true) }
        addKey(r2, "⇤ البداية", 1f, special = true, textSize = 13f) { moveCursor(KeyEvent.KEYCODE_MOVE_HOME, false) }
        addKey(r2, "النهاية ⇥", 1f, special = true, textSize = 13f) { moveCursor(KeyEvent.KEYCODE_MOVE_END, false) }
        container.addView(r2)

        val r3 = newRow()
        addKey(r3, "« كلمة", 1f, special = true, textSize = 13f) { moveCursor(KeyEvent.KEYCODE_DPAD_LEFT, true) }
        addKey(r3, "◀", 1f, special = true, textSize = 16f) { moveCursor(KeyEvent.KEYCODE_DPAD_LEFT, false) }
        addKey(r3, "▶", 1f, special = true, textSize = 16f) { moveCursor(KeyEvent.KEYCODE_DPAD_RIGHT, false) }
        addKey(r3, "كلمة »", 1f, special = true, textSize = 13f) { moveCursor(KeyEvent.KEYCODE_DPAD_RIGHT, true) }
        container.addView(r3)

        // "تحديد": أثناء تفعيله تمدّ الأسهم التحديد بدل تحريك المؤشر
        val r4 = newRow()
        addKey(r4, "تحديد", 1.4f, special = true, active = selectMode, textSize = 13f) {
            selectMode = !selectMode
            renderKeys()
        }
        addKey(r4, "AB", 1f, textSize = 14f) { convertSelectionCase(0) }
        addKey(r4, "ab", 1f, textSize = 14f) { convertSelectionCase(1) }
        addKey(r4, "Ab", 1f, textSize = 14f) { convertSelectionCase(2) }
        addKey(r4, "✨", 1f, textSize = 16f) { setMode(Mode.AI) }
        addKey(r4, if (isArabic) "أ ب ج" else "ABC", 1.2f, special = true, textSize = 13f) { setMode(lastLetterMode) }
        container.addView(r4)
    }

    // ------------------------------------------------------------------ أدوات الذكاء الاصطناعي

    private var aiBusy = false
    private var aiStatus: TextView? = null
    private var aiUndo: Pair<String, String>? = null // (النص الأصلي، الناتج)

    private fun setAiStatus(msg: String) {
        aiStatus?.text = msg
    }

    private fun renderAi(container: LinearLayout) {
        val s = settings()

        if (!s.getBoolean("ai_consent", false)) {
            val tv = TextView(this)
            tv.text = "أدوات الذكاء الاصطناعي ترسل النص الذي تختاره إلى خوادم Anthropic عبر مفتاح API " +
                "الخاص بك لمعالجته. لا تعمل في حقول كلمات المرور. هل توافق؟"
            tv.setTextColor(theme.text)
            tv.textSize = 14f
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(12), dp(8), dp(12), dp(8))
            container.addView(tv, LinearLayout.LayoutParams(MATCH, dp(130)))
            val row = newRow()
            addKey(row, "أوافق", 2f, textSize = 14f) {
                s.edit().putBoolean("ai_consent", true).apply()
                renderKeys()
            }
            addKey(row, "رجوع", 1f, special = true, textSize = 14f) { setMode(Mode.TOOLS) }
            container.addView(row)
            return
        }

        val r1 = newRow()
        addKey(r1, "تصحيح", 1f, textSize = 14f) { runAi(AI_FIX) }
        addKey(r1, "إعادة صياغة", 1f, textSize = 14f) { runAi(AI_REPHRASE) }
        addKey(r1, "رسمي", 1f, textSize = 14f) { runAi(AI_FORMAL) }
        container.addView(r1)

        val r2 = newRow()
        addKey(r2, "ودّي", 1f, textSize = 14f) { runAi(AI_FRIENDLY) }
        addKey(r2, "اختصار", 1f, textSize = 14f) { runAi(AI_SHORT) }
        addKey(r2, "ترجمة", 1f, textSize = 14f) { runAi(AI_TRANSLATE) }
        container.addView(r2)

        val status = TextView(this)
        status.text = if (aiBusy) "جارٍ المعالجة…" else "يعمل على النص المحدد، أو على الفقرة قبل المؤشر"
        status.textSize = 13f
        status.gravity = Gravity.CENTER
        status.setTextColor(theme.text)
        aiStatus = status
        container.addView(status, LinearLayout.LayoutParams(MATCH, dp(46)))

        val r3 = newRow()
        addKey(r3, "↩ الأصل", 1.5f, special = true, textSize = 14f) { aiRestore() }
        addKey(r3, "🛠 أدوات", 1.5f, special = true, textSize = 14f) { setMode(Mode.TOOLS) }
        addKey(r3, if (isArabic) "أ ب ج" else "ABC", 1f, special = true) { setMode(lastLetterMode) }
        container.addView(r3)
    }

    private fun runAi(instruction: String) {
        if (aiBusy) return
        if (isPasswordField) {
            setAiStatus("غير متاح في حقول كلمات المرور")
            return
        }
        val s = settings()
        val apiKey = s.getString("ai_key", "").orEmpty().trim()
        if (apiKey.isEmpty()) {
            setAiStatus("أدخل مفتاح API من شاشة التطبيق أولاً")
            return
        }
        val model = s.getString("ai_model", AiClient.DEFAULT_MODEL).orEmpty().ifBlank { AiClient.DEFAULT_MODEL }
        val ic = currentInputConnection ?: return
        finishComposing()

        val selected = ic.getSelectedText(0)?.toString().orEmpty()
        val fromSelection = selected.isNotEmpty()
        val source = if (fromSelection) {
            selected
        } else {
            ic.getTextBeforeCursor(1000, 0)?.toString().orEmpty().substringAfterLast('\n')
        }
        if (source.isBlank()) {
            setAiStatus("لا يوجد نص لمعالجته")
            return
        }
        if (source.length > 3000) {
            setAiStatus("النص طويل (أكثر من 3000 حرف)")
            return
        }

        aiBusy = true
        setAiStatus("جارٍ المعالجة…")
        AiClient.run(
            apiKey, model, instruction, source,
            onSuccess = { result -> handler.post { applyAi(source, result, fromSelection) } },
            onError = { msg ->
                handler.post {
                    aiBusy = false
                    setAiStatus(msg)
                }
            }
        )
    }

    /** يستبدل النص الأصلي بالناتج بشرط ألا يكون المستخدم قد غيّره أثناء المعالجة */
    private fun applyAi(source: String, result: String, fromSelection: Boolean) {
        aiBusy = false
        val ic = currentInputConnection ?: return
        val ok: Boolean
        if (fromSelection) {
            ok = ic.getSelectedText(0)?.toString() == source
            if (ok) ic.commitText(result, 1)
        } else {
            ok = ic.getTextBeforeCursor(source.length, 0)?.toString() == source
            if (ok) {
                ic.deleteSurroundingText(source.length, 0)
                ic.commitText(result, 1)
            }
        }
        if (ok) {
            lastKeyTime = SystemClock.uptimeMillis()
            aiUndo = Pair(source, result)
            setAiStatus("تم ✓  (↩ لاسترجاع الأصل)")
        } else {
            setAiStatus("تغيّر النص أثناء المعالجة، لم يُطبَّق")
        }
    }

    private fun aiRestore() {
        val saved = aiUndo
        if (saved == null) {
            setAiStatus("لا يوجد شيء للاسترجاع")
            return
        }
        val ic = currentInputConnection ?: return
        val (original, result) = saved
        if (ic.getTextBeforeCursor(result.length, 0)?.toString() == result) {
            ic.deleteSurroundingText(result.length, 0)
            ic.commitText(original, 1)
            aiUndo = null
            lastKeyTime = SystemClock.uptimeMillis()
            setAiStatus("تمت استعادة النص الأصلي")
        } else {
            setAiStatus("تغيّر النص، تعذّرت الاستعادة")
        }
    }

    // ------------------------------------------------------------------ اقتراح الإيموجي

    private fun insertEmojiAfterWord(e: String) {
        val ic = currentInputConnection ?: return
        lastKeyTime = SystemClock.uptimeMillis()
        finishComposing()
        ic.commitText(" $e ", 1)
        updateSuggestions()
    }

    // ------------------------------------------------------------------ الإدخال الصوتي

    private fun startVoice() {
        finishComposing()
        val intent = Intent(this, VoiceInputActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra(VoiceInputActivity.EXTRA_LANGUAGE, if (isArabic) "ar-SA" else "en-US")
        startActivity(intent)
    }
}
