package com.example.mykeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable

/** شكل المفاتيح: مستطيل مدوّر، كبسولة، أو دائري. */
object KeyShapes {
    const val PREF = "key_shape"
    val ids = listOf("round", "pill", "circle")
    val names = listOf("مستطيل مدوّر", "كبسولة", "دائري")

    fun read(context: Context): String =
        context.getSharedPreferences(FeedbackHelper.PREFS, Context.MODE_PRIVATE)
            .getString(PREF, "round") ?: "round"

    /**
     * خلفية مفتاح بحالتين (عادي/مضغوط).
     * [narrow] = مفتاح بعرض عادي: في الوضع الدائري يصبح دائرة، أما العريض (المسافة، Enter...) فكبسولة.
     */
    fun background(shape: String, fill: Int, pressed: Int, narrow: Boolean, radiusPx: Float): StateListDrawable {
        fun make(c: Int): Drawable = when {
            shape == "circle" && narrow -> CircleDrawable(c)
            shape == "pill" || shape == "circle" -> GradientDrawable().apply {
                cornerRadius = 1000f // يُقصّ تلقائياً إلى نصف الارتفاع
                setColor(c)
            }
            else -> GradientDrawable().apply {
                cornerRadius = radiusPx
                setColor(c)
            }
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), make(pressed))
            addState(intArrayOf(), make(fill))
        }
    }
}

/** دائرة قطرها أصغر بُعد في المساحة المتاحة (حتى لو كان المفتاح مستطيلاً). */
class CircleDrawable(fill: Int) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fill }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val r = minOf(b.width(), b.height()) / 2f
        canvas.drawCircle(b.exactCenterX(), b.exactCenterY(), r, paint)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
