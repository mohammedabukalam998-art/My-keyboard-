package com.example.mykeyboard

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

/** إدارة الاختصارات النصية. */
class ShortcutsActivity : ComponentActivity() {

    private lateinit var store: ShortcutStore
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ShortcutStore(this)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun add(v: View) = root.addView(
            v, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = pad / 2 }
        )

        val title = TextView(this)
        title.text = "الاختصارات النصية"
        title.textSize = 20f
        add(title)

        val help = TextView(this)
        help.text = "اكتب الاختصار ثم اضغط مسافة فيتحول إلى النص الكامل.\nمثال: @em ← name@example.com"
        add(help)

        val trigger = EditText(this)
        trigger.hint = "الاختصار (بدون مسافات)"
        add(trigger)

        val expansion = EditText(this)
        expansion.hint = "النص الكامل"
        expansion.minLines = 2
        add(expansion)

        val save = Button(this)
        save.text = "إضافة / تحديث"
        save.setOnClickListener {
            val t = trigger.text.toString().trim()
            val e = expansion.text.toString()
            when {
                t.isEmpty() || e.isBlank() ->
                    Toast.makeText(this, "املأ الحقلين", Toast.LENGTH_SHORT).show()
                t.any { it.isWhitespace() } || t.length > 24 ->
                    Toast.makeText(this, "الاختصار بدون مسافات وبحد أقصى 24 حرفاً", Toast.LENGTH_LONG).show()
                else -> {
                    store.put(t, e)
                    trigger.setText("")
                    expansion.setText("")
                    refresh()
                }
            }
        }
        add(save)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        add(list)
        refresh()

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun refresh() {
        list.removeAllViews()
        val all = store.getAll()
        if (all.isEmpty()) {
            val empty = TextView(this)
            empty.text = "لا توجد اختصارات بعد"
            list.addView(empty)
            return
        }
        for ((k, v) in all) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL

            val tv = TextView(this)
            tv.text = "$k  ←  ${v.replace('\n', ' ')}"
            row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            val del = Button(this)
            del.text = "حذف"
            del.setOnClickListener {
                store.remove(k)
                refresh()
            }
            row.addView(del)
            list.addView(row)
        }
    }
}
