package com.example.mykeyboard

/**
 * تحويل الكتابة بالحروف اللاتينية (فرانكو/عربيزي) إلى عربي، مثل marhaba ← مرحبا.
 * نولّد احتمالات الكتابة (حروف العلة اختيارية) ونُبقي فقط ما يطابق كلمات في القاموس العربي.
 * الأرقام: 2=ء 3=ع 5=خ 6=ط 7=ح 8=ق 9=ص
 */
class FrancoArabic(private val dictionary: SimpleDictionary) {

    private val digraphs = mapOf(
        "sh" to listOf("ش"), "kh" to listOf("خ"), "gh" to listOf("غ"),
        "th" to listOf("ث", "ذ"), "dh" to listOf("ذ", "ض"),
        "aa" to listOf("ا"), "ee" to listOf("ي"), "oo" to listOf("و"), "ou" to listOf("و")
    )

    private val consonants = mapOf(
        'b' to listOf("ب"), 't' to listOf("ت", "ط"), 'j' to listOf("ج"), 'd' to listOf("د", "ض"),
        'r' to listOf("ر"), 'z' to listOf("ز", "ظ"), 's' to listOf("س", "ص"), 'f' to listOf("ف"),
        'q' to listOf("ق"), 'k' to listOf("ك"), 'l' to listOf("ل"), 'm' to listOf("م"),
        'n' to listOf("ن"), 'h' to listOf("ه", "ح"), 'w' to listOf("و"), 'y' to listOf("ي"),
        'g' to listOf("ج", "غ"), 'p' to listOf("ب"), 'v' to listOf("ف"), 'c' to listOf("ك", "س"),
        'x' to listOf("كس"),
        '2' to listOf("ا", "ء"), '3' to listOf("ع"), '5' to listOf("خ"), '6' to listOf("ط"),
        '7' to listOf("ح"), '8' to listOf("ق"), '9' to listOf("ص", "ق")
    )

    private fun vowelOptions(c: Char, first: Boolean, last: Boolean): List<String> {
        val long = when (c) { 'a' -> "ا"; 'e', 'i' -> "ي"; else -> "و" }
        return when {
            first && last -> listOf(long)
            first -> if (c == 'o' || c == 'u') listOf("ا", "و") else listOf("ا")
            last -> when (c) { 'a' -> listOf("ه", "ا"); 'e' -> listOf("ه", "ي"); 'i' -> listOf("ي"); else -> listOf("و") }
            else -> listOf("", long)
        }
    }

    private fun tokenize(s: String): List<List<String>>? {
        val w = s.lowercase()
        val units = ArrayList<List<String>>()
        var i = 0
        while (i < w.length) {
            val two = if (i + 1 < w.length) w.substring(i, i + 2) else null
            val dg = if (two != null) digraphs[two] else null
            if (dg != null) {
                units.add(dg)
                i += 2
                continue
            }
            val c = w[i]
            val opts = if (c in "aeiou") vowelOptions(c, i == 0, i == w.length - 1) else consonants[c]
            if (opts == null) return null
            units.add(opts)
            i++
        }
        return units
    }

    /** أفضل [max] كلمات عربية مطابقة (أو كتابة حرفية إن لم نجد في القاموس) */
    fun candidates(latin: String, max: Int = 2): List<String> {
        if (latin.length < 2 || latin.none { it.isLetter() }) return emptyList()
        val units = tokenize(latin) ?: return emptyList()

        val scored = HashMap<String, Int>()
        var budget = 800
        fun dfs(i: Int, cur: String) {
            if (budget <= 0) return
            budget--
            if (cur.isNotEmpty() && !dictionary.arabicHasPrefix(cur)) return
            if (i == units.size) {
                for ((word, score) in dictionary.arabicMatches(cur, 3)) {
                    val old = scored[word]
                    if (old == null || score < old) scored[word] = score
                }
                return
            }
            for (opt in units[i]) dfs(i + 1, cur + opt)
        }
        dfs(0, "")

        val best = scored.entries.sortedBy { it.value }.take(max).map { it.key }
        if (best.isNotEmpty()) return best
        val lit = literal(latin)
        return if (lit.isNotEmpty()) listOf(lit) else emptyList()
    }

    /** كتابة حرفية (للأسماء غير الموجودة في القاموس) */
    private fun literal(latin: String): String {
        val w = latin.lowercase()
        val sb = StringBuilder()
        var i = 0
        while (i < w.length) {
            val two = if (i + 1 < w.length) w.substring(i, i + 2) else null
            val dg = if (two != null) digraphs[two] else null
            if (dg != null) {
                sb.append(dg[0])
                i += 2
                continue
            }
            val c = w[i]
            if (c in "aeiou") {
                if (i == 0) sb.append("ا")
                else if (i == w.length - 1) sb.append(when (c) { 'a' -> "ا"; 'e', 'i' -> "ي"; else -> "و" })
            } else {
                val o = consonants[c] ?: return ""
                sb.append(o[0])
            }
            i++
        }
        return sb.toString()
    }
}
