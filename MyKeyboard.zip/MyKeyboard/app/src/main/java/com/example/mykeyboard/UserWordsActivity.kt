package com.example.mykeyboard

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

/** الكلمات التي تعلّمها الكيبورد من كتابتك: عرض وحذف. */
class UserWordsActivity : ComponentActivity() {

    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun add(v: View) = root.addView(
            v, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = pad / 2 }
        )

        val title = TextView(this)
        title.text = "الكلمات المحفوظة"
        title.textSize = 20f
        add(title)

        val help = TextView(this)
        help.text = "كلمات تعلّمها الكيبورد من كتابتك. احذف أي كلمة لا تريد أن تظهر في الاقتراحات."
        add(help)

        val clearAll = Button(this)
        clearAll.text = "مسح كل ما تعلّمه الكيبورد (الكلمات والعبارات)"
        clearAll.setOnClickListener {
            for (name in listOf("user_dict_en", "user_dict_ar", "nextword")) {
                getSharedPreferences(name, MODE_PRIVATE).edit().clear().apply()
            }
            Toast.makeText(this, "تم المسح", Toast.LENGTH_SHORT).show()
            refresh()
        }
        add(clearAll)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        add(list)
        refresh()

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun refresh() {
        list.removeAllViews()
        section("كلمات عربية", "user_dict_ar")
        section("English words", "user_dict_en")
    }

    private fun section(title: String, prefName: String) {
        val prefs = getSharedPreferences(prefName, MODE_PRIVATE)
        val header = TextView(this)
        header.text = title
        header.textSize = 16f
        list.addView(header)

        val words = prefs.all.entries
            .map { Pair(it.key, (it.value as? Int) ?: 0) }
            .sortedByDescending { it.second }
            .take(200)

        if (words.isEmpty()) {
            val empty = TextView(this)
            empty.text = "لا توجد كلمات"
            list.addView(empty)
            return
        }
        for ((word, count) in words) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL

            val tv = TextView(this)
            tv.text = "$word  ($count)"
            row.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            val del = Button(this)
            del.text = "حذف"
            del.setOnClickListener {
                prefs.edit().remove(word).apply()
                refresh()
            }
            row.addView(del)
            list.addView(row)
        }
    }
}
