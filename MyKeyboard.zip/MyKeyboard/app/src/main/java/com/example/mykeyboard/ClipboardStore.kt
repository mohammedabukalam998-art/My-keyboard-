package com.example.mykeyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

data class ClipItem(val text: String, val pinned: Boolean)

/** سجل الحافظة: آخر 30 عنصراً + العناصر المثبّتة (تُحفظ على الجهاز فقط). */
class ClipboardStore(context: Context) {

    private val prefs = context.getSharedPreferences("clipboard", Context.MODE_PRIVATE)

    fun load(): List<ClipItem> {
        val arr = try {
            JSONArray(prefs.getString("items", "[]") ?: "[]")
        } catch (e: JSONException) {
            JSONArray()
        }
        val out = ArrayList<ClipItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val t = o.optString("t")
            if (t.isNotEmpty()) out.add(ClipItem(t, o.optBoolean("p")))
        }
        return out
    }

    private fun save(items: List<ClipItem>) {
        val arr = JSONArray()
        for (it in items) arr.put(JSONObject().put("t", it.text).put("p", it.pinned))
        prefs.edit().putString("items", arr.toString()).apply()
    }

    fun add(text: String) {
        val items = load().toMutableList()
        val old = items.firstOrNull { it.text == text }
        items.removeAll { it.text == text }
        items.add(0, ClipItem(text, old?.pinned ?: false))
        val pinned = items.filter { it.pinned }
        val recent = items.filter { !it.pinned }.take(MAX_RECENT)
        save((pinned + recent).sortedByDescending { it.pinned })
    }

    fun togglePin(text: String) =
        save(load().map { if (it.text == text) it.copy(pinned = !it.pinned) else it })

    fun delete(text: String) = save(load().filter { it.text != text })

    fun clearUnpinned() = save(load().filter { it.pinned })

    private companion object {
        const val MAX_RECENT = 30
    }
}
