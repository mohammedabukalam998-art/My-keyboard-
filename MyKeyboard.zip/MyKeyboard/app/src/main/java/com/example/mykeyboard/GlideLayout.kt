package com.example.mykeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.hypot

/** مفتاح حرف: مركزه وأبعاده بإحداثيات هذا الـ Layout */
class GlideKey(val ch: Char, val cx: Float, val cy: Float, val w: Float, val h: Float)

/**
 * حاوية الصفوف. تلتقط حركة الإصبع عندما تبدأ على حرف وتتجاوز مسافة معيّنة،
 * فتتحول من "ضغطة" إلى "رسم مسار" (الكتابة بالسحب) وترسم أثر الإصبع.
 * المفاتيح التي لها Glide تحمل tag = الحرف.
 */
class GlideLayout(context: Context) : LinearLayout(context) {

    var glideEnabled = true
    var canStart: () -> Boolean = { true }
    var trailColor = 0xFF4A90D9.toInt()
    var onGlide: (List<PointF>, List<GlideKey>) -> Unit = { _, _ -> }

    private val path = ArrayList<PointF>()
    private val trail = Path()
    private var keys: List<GlideKey> = emptyList()
    private var candidate = false
    private var gliding = false
    private var downX = 0f
    private var downY = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init {
        setWillNotDraw(false)
    }

    private fun collectKeys(): List<GlideKey> {
        val out = ArrayList<GlideKey>()
        fun walk(group: ViewGroup, gx: Float, gy: Float) {
            for (i in 0 until group.childCount) {
                val c = group.getChildAt(i)
                val x = gx + c.left
                val y = gy + c.top
                val tag = c.tag
                if (tag is String && tag.isNotEmpty()) {
                    out.add(GlideKey(tag[0], x + c.width / 2f, y + c.height / 2f, c.width.toFloat(), c.height.toFloat()))
                } else if (c is ViewGroup) {
                    walk(c, x, y)
                }
            }
        }
        walk(this, 0f, 0f)
        return out
    }

    private fun addPoints(e: MotionEvent) {
        for (i in 0 until e.historySize) {
            val p = PointF(e.getHistoricalX(i), e.getHistoricalY(i))
            path.add(p)
            trail.lineTo(p.x, p.y)
        }
        path.add(PointF(e.x, e.y))
        trail.lineTo(e.x, e.y)
    }

    private fun reset() {
        gliding = false
        candidate = false
        path.clear()
        trail.reset()
        invalidate()
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                path.clear()
                trail.reset()
                gliding = false
                candidate = false
                if (glideEnabled && canStart()) {
                    keys = collectKeys()
                    val hit = keys.any { abs(e.x - it.cx) <= it.w / 2 && abs(e.y - it.cy) <= it.h / 2 }
                    if (keys.size >= 5 && hit) {
                        candidate = true
                        downX = e.x
                        downY = e.y
                        path.add(PointF(e.x, e.y))
                        trail.moveTo(e.x, e.y)
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> if (candidate && !gliding) {
                if (!canStart()) {
                    candidate = false // مثلاً ظهرت نافذة الرموز البديلة
                    return false
                }
                addPoints(e)
                val threshold = keys.first().w * 1.0f
                if (hypot(e.x - downX, e.y - downY) > threshold) {
                    gliding = true
                    invalidate()
                    return true // يُلغي ضغطة المفتاح ويحوّل الحركة إلينا
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> candidate = false
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!gliding) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                addPoints(e)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                addPoints(e)
                val points = ArrayList(path)
                val k = keys
                reset()
                onGlide(points, k)
            }
            MotionEvent.ACTION_CANCEL -> reset()
        }
        return true
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        if (gliding) {
            paint.color = (trailColor and 0x00FFFFFF) or (0xA0 shl 24)
            paint.strokeWidth = (keys.firstOrNull()?.h ?: 40f) * 0.22f
            canvas.drawPath(trail, paint)
        }
    }
}
