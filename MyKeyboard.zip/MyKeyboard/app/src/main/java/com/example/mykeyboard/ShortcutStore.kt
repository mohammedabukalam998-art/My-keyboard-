package com.example.mykeyboard

import android.content.Context
import org.json.JSONException
import org.json.JSONObject

/** الاختصارات النصية: اختصار ← نص كامل. */
class ShortcutStore(context: Context) {

    private val prefs = context.getSharedPreferences("shortcuts", Context.MODE_PRIVATE)

    fun getAll(): LinkedHashMap<String, String> {
        val out = LinkedHashMap<String, String>()
        try {
            val o = JSONObject(prefs.getString("map", "{}") ?: "{}")
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                out[k] = o.optString(k)
            }
        } catch (e: JSONException) {
            // نتجاهل البيانات التالفة
        }
        return out
    }

    private fun save(map: Map<String, String>) {
        val o = JSONObject()
        for ((k, v) in map) o.put(k, v)
        prefs.edit().putString("map", o.toString()).apply()
    }

    fun put(trigger: String, expansion: String) {
        val m = getAll()
        m[trigger] = expansion
        save(m)
    }

    fun remove(trigger: String) {
        val m = getAll()
        m.remove(trigger)
        save(m)
    }
}
