package com.example.mykeyboard

import android.content.Context
import java.io.IOException

/**
 * قاموس بسيط: كلمات مدمجة + كلمات يتعلمها من المستخدم.
 * لقاموس أكبر: ضع ملفي words_en.txt و words_ar.txt في app/src/main/assets
 * (كلمة في كل سطر، الأكثر شيوعاً أولاً) وسيُستخدمان تلقائياً.
 */
class SimpleDictionary(private val context: Context) {

    private val english = loadAsset("words_en.txt", DEFAULT_EN)
    private val arabic = loadAsset("words_ar.txt", DEFAULT_AR)

    private fun loadAsset(name: String, default: List<String>): List<String> = try {
        context.assets.open(name).bufferedReader().useLines { lines ->
            lines.map { it.trim() }.filter { it.isNotEmpty() }.toList()
        }
    } catch (e: IOException) {
        default
    }

    private fun userPrefs(isArabic: Boolean) = context.getSharedPreferences(
        if (isArabic) "user_dict_ar" else "user_dict_en", Context.MODE_PRIVATE
    )

    fun suggest(prefix: String, isArabic: Boolean, max: Int = 3): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val capitalize = !isArabic && prefix.first().isUpperCase()

        val user = userPrefs(isArabic).all.entries
            .filter {
                it.key.startsWith(prefix, ignoreCase = true) &&
                    !it.key.equals(prefix, ignoreCase = true)
            }
            .sortedByDescending { (it.value as? Int) ?: 0 }
            .map { it.key }

        val builtIn = (if (isArabic) arabic else english).filter {
            it.startsWith(prefix, ignoreCase = true) && !it.equals(prefix, ignoreCase = true)
        }

        return (user + builtIn).distinct().take(max).map { w ->
            if (capitalize) w.replaceFirstChar { it.uppercase() } else w
        }
    }

    /** يحفظ الكلمة التي كتبها المستخدم ليقترحها لاحقاً */
    fun learn(word: String, isArabic: Boolean) {
        val w = if (isArabic) word else word.lowercase()
        if (w.length < 2 || !w.all { it.isLetter() || it == '\'' }) return
        val p = userPrefs(isArabic)
        p.edit().putInt(w, p.getInt(w, 0) + 1).apply()
    }

    private companion object {
        val DEFAULT_EN = (
            "the be to of and a in that have I it for not on with he as you do at this but his by from " +
            "they we say her she or an will my one all would there their what so up out if about who get " +
            "which go me when make can like time no just him know take people into year your good some " +
            "could them see other than then now look only come its over think also back after use two how " +
            "our work first well way even new want because any these give day most us hello help here " +
            "thanks thank please keyboard android kotlin developer tomorrow today welcome where why yes " +
            "okay morning night love friend great"
            ).split(" ")

        val DEFAULT_AR = (
            "في من على إلى أن هذا هذه ما لا هل كيف أين متى لماذا ماذا مرحبا السلام عليكم ورحمة الله " +
            "وبركاته أهلا وسهلا شكرا جزيلا عفوا فضلك نعم صباح الخير مساء النور اليوم غدا الآن كل بعد " +
            "قبل مع عن أنا أنت هو هي نحن هم الكيبورد تطبيق برمجة أندرويد محمد أحمد علي مصر السعودية " +
            "العربية اللغة الحمد لله إن شاء بارك العافية كتاب بيت عمل صديق حب وقت لكن أو ثم لقد كان " +
            "يكون قد حتى"
            ).split(" ")
    }
}
