package com.example.mykeyboard

import android.content.Context
import java.io.File
import java.util.TreeMap

/**
 * قاموس يدعم عشرات الآلاف من الكلمات.
 *
 * مصادر التحميل بالترتيب:
 *  1) ملف استوردته من التطبيق (filesDir/words_en.txt أو words_ar.txt)
 *  2) ملف في assets (يُنزَّل تلقائياً عند البناء على GitHub)
 *  3) قائمة صغيرة مدمجة
 *
 * صيغة الملف: كلمة في كل سطر، الأكثر شيوعاً أولاً.
 * يُقبل أيضاً سطر بالصيغة "كلمة عدد" (مثل ملفات FrequencyWords).
 */
class SimpleDictionary(private val context: Context) {

    private class Entry(val word: String, val rank: Int)

    @Volatile private var enIndex: TreeMap<String, Entry> = build(DEFAULT_EN, false)
    @Volatile private var arIndex: TreeMap<String, Entry> = build(DEFAULT_AR, true)
    private var enStamp = -1L
    private var arStamp = -1L

    init {
        refreshIfNeeded()
    }

    /** يعيد تحميل القواميس (في خيط خلفي) إذا تغيّر الملف المستورد */
    @Synchronized
    fun refreshIfNeeded() {
        val en = stamp(EN_FILE)
        if (en != enStamp) {
            enStamp = en
            loadAsync(false)
        }
        val ar = stamp(AR_FILE)
        if (ar != arStamp) {
            arStamp = ar
            loadAsync(true)
        }
    }

    private fun stamp(name: String): Long {
        val f = File(context.filesDir, name)
        return if (f.exists()) f.lastModified() else 0L
    }

    private fun loadAsync(arabic: Boolean) {
        Thread {
            val lines = readLines(if (arabic) AR_FILE else EN_FILE)
            if (lines != null) {
                val index = build(lines, arabic)
                if (arabic) arIndex = index else enIndex = index
            }
        }.start()
    }

    private fun readLines(name: String): List<String>? = try {
        val f = File(context.filesDir, name)
        if (f.exists() && f.length() > 0) {
            f.bufferedReader().useLines { it.take(MAX_LINES).toList() }
        } else {
            context.assets.open(name).bufferedReader().useLines { it.take(MAX_LINES).toList() }
        }
    } catch (e: Exception) {
        null // لا يوجد ملف: نبقى على القائمة المدمجة
    }

    // ------------------------------------------------------------------ البناء والبحث

    private fun isMark(c: Char) = c in '\u064B'..'\u065F' || c == '\u0670' || c == '\u0640'

    /** مفتاح البحث: أحرف صغيرة، وفي العربية نحذف التشكيل والتطويل */
    private fun norm(w: String, arabic: Boolean): String {
        val lower = w.lowercase()
        if (!arabic) return lower
        // نحذف التشكيل ونوحّد صور الألف والياء والتاء المربوطة ليتسامح البحث مع الأخطاء الإملائية
        return buildString {
            for (c in lower) {
                if (isMark(c)) continue
                append(
                    when (c) {
                        'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                        'ى' -> 'ي'
                        'ة' -> 'ه'
                        else -> c
                    }
                )
            }
        }
    }

    private fun build(lines: List<String>, arabic: Boolean): TreeMap<String, Entry> {
        val map = TreeMap<String, Entry>()
        var rank = 0
        for (raw in lines) {
            val line = raw.trim().trimStart('\uFEFF')
            val cut = line.indexOfFirst { it.isWhitespace() }
            val word = if (cut >= 0) line.substring(0, cut) else line
            if (word.isEmpty() || word.length > 24 || !word.first().isLetter()) continue
            if (!word.all { it.isLetter() || it == '\'' || (arabic && isMark(it)) }) continue
            if (word.length == 1 && (arabic || word.lowercase() !in setOf("a", "i"))) continue
            val key = norm(word, arabic)
            if (!map.containsKey(key)) map[key] = Entry(word, rank++)
        }
        return map
    }

    private fun userPrefs(isArabic: Boolean) = context.getSharedPreferences(
        if (isArabic) "user_dict_ar" else "user_dict_en", Context.MODE_PRIVATE
    )

    fun suggest(prefix: String, isArabic: Boolean, max: Int = 3): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val key = norm(prefix, isArabic)
        if (key.isEmpty()) return emptyList()
        val capitalize = !isArabic && prefix.first().isUpperCase()

        // كلمات المستخدم أولاً (الأكثر استخداماً)
        val user = userPrefs(isArabic).all.entries
            .filter {
                it.key.startsWith(prefix, ignoreCase = true) &&
                    !it.key.equals(prefix, ignoreCase = true)
            }
            .sortedByDescending { (it.value as? Int) ?: 0 }
            .map { it.key }

        // ثم أشيع الكلمات في القاموس التي تبدأ بالمدخل
        val index = if (isArabic) arIndex else enIndex
        val best = ArrayList<Entry>(max + 1)
        for ((k, e) in index.subMap(key, true, key + '\uffff', true)) {
            if (k == key) continue
            var pos = best.size
            while (pos > 0 && best[pos - 1].rank > e.rank) pos--
            if (pos < max) {
                best.add(pos, e)
                if (best.size > max) best.removeAt(best.size - 1)
            }
        }

        return (user + best.map { it.word }).distinct().take(max).map { w ->
            if (capitalize) w.replaceFirstChar { it.uppercase() } else w
        }
    }

    /** هل توجد كلمة عربية تبدأ بهذا المفتاح (مُطبَّع)؟ */
    fun arabicHasPrefix(key: String): Boolean {
        val k = arIndex.ceilingKey(key)
        return k != null && k.startsWith(key)
    }

    /** أفضل كلمات عربية تبدأ بالمفتاح: (الكلمة، الدرجة) والأقل أفضل */
    fun arabicMatches(key: String, max: Int): List<Pair<String, Int>> {
        val best = ArrayList<Pair<String, Int>>(max + 1)
        for ((k, e) in arIndex.subMap(key, true, key + '\uffff', true)) {
            val score = e.rank + (k.length - key.length) * 400
            var pos = best.size
            while (pos > 0 && best[pos - 1].second > score) pos--
            if (pos < max) {
                best.add(pos, Pair(e.word, score))
                if (best.size > max) best.removeAt(best.size - 1)
            }
        }
        return best
    }

    private val neighbors = mapOf(
        'q' to "wa", 'w' to "qesa", 'e' to "wrsd", 'r' to "etdf", 't' to "ryfg", 'y' to "tugh",
        'u' to "yihj", 'i' to "uojk", 'o' to "ipkl", 'p' to "ol", 'a' to "qwsz", 's' to "awedxz",
        'd' to "serfcx", 'f' to "drtgvc", 'g' to "ftyhbv", 'h' to "gyujnb", 'j' to "huikmn",
        'k' to "jiolm", 'l' to "kop", 'z' to "asx", 'x' to "zsdc", 'c' to "xdfv", 'v' to "cfgb",
        'b' to "vghn", 'n' to "bhjm", 'm' to "njk"
    )

    /**
     * تصحيح تلقائي: أقرب كلمة شائعة بتعديل واحد (حذف/تبديل/استبدال/إضافة حرف).
     * يرجع null إذا الكلمة معروفة أو لا يوجد تصحيح موثوق.
     * الاستبدال بمفتاح مجاور في QWERTY والتبديل بين حرفين متجاورين أرجح من غيرهما.
     */
    fun correct(word: String, arabic: Boolean): String? {
        val index = if (arabic) arIndex else enIndex
        if (index.size < MIN_LARGE) return null // القاموس الصغير المدمج لا يكفي للتصحيح
        val key = norm(word, arabic)
        if (key.length < (if (arabic) 4 else 3) || key.length > 20) return null
        if (index.containsKey(key)) return null
        val userKey = if (arabic) word else word.lowercase()
        if (userPrefs(arabic).getInt(userKey, 0) >= 2) return null // كلمة اعتاد المستخدم كتابتها

        val alphabet = if (arabic) AR_ALPHABET else EN_ALPHABET
        val limit = if (arabic) 15_000 else 30_000
        var best: Entry? = null
        var bestScore = Double.MAX_VALUE
        fun consider(cand: String, factor: Double) {
            val e = index[cand] ?: return
            if (e.rank > limit) return
            val score = (e.rank + 1) * factor
            if (score < bestScore) {
                bestScore = score
                best = e
            }
        }

        for (i in key.indices) {
            consider(key.removeRange(i, i + 1), if (i > 0 && key[i] == key[i - 1]) 1.5 else 3.0)
        }
        for (i in 0 until key.length - 1) {
            if (key[i] != key[i + 1]) {
                val c = key.toCharArray()
                val t = c[i]
                c[i] = c[i + 1]
                c[i + 1] = t
                consider(String(c), 1.0)
            }
        }
        for (i in key.indices) {
            for (ch in alphabet) {
                if (ch == key[i]) continue
                val near = !arabic && (neighbors[key[i]]?.indexOf(ch) ?: -1) >= 0
                consider(key.substring(0, i) + ch + key.substring(i + 1), if (near) 1.5 else 3.0)
            }
        }
        for (i in 0..key.length) {
            for (ch in alphabet) {
                consider(key.substring(0, i) + ch + key.substring(i), if (ch == '\'') 1.0 else 3.0)
            }
        }
        val result = best?.word ?: return null
        return if (result.equals(word, ignoreCase = true)) null else result
    }

    /** كلمات القاموس التي يبدأ مفتاحها بأحد الأحرف المعطاة (للكتابة بالسحب) */
    fun glideCandidates(firstChars: Set<Char>, arabic: Boolean): List<GlideWord> {
        val out = ArrayList<GlideWord>()
        for ((k, e) in (if (arabic) arIndex else enIndex)) {
            if (k.length < 2 || k.length > 16 || k[0] !in firstChars) continue
            out.add(GlideWord(e.word, k, e.rank))
        }
        return out
    }

    /** يحفظ الكلمة التي كتبها المستخدم ليقترحها لاحقاً */
    fun learn(word: String, isArabic: Boolean) {
        val w = if (isArabic) word else word.lowercase()
        if (w.length < 2 || !w.all { it.isLetter() || it == '\'' }) return
        val p = userPrefs(isArabic)
        p.edit().putInt(w, p.getInt(w, 0) + 1).apply()
    }

    companion object {
        const val EN_FILE = "words_en.txt"
        const val AR_FILE = "words_ar.txt"
        private const val MAX_LINES = 80_000
        private const val MIN_LARGE = 5000
        private const val EN_ALPHABET = "abcdefghijklmnopqrstuvwxyz'"
        private const val AR_ALPHABET = "ابتثجحخدذرزسشصضطظعغفقكلمنهويءؤئ"

        private val DEFAULT_EN = (
            "the be to of and a in that have I it for not on with he as you do at this but his by from " +
            "they we say her she or an will my one all would there their what so up out if about who get " +
            "which go me when make can like time no just him know take people into year your good some " +
            "could them see other than then now look only come its over think also back after use two how " +
            "our work first well way even new want because any these give day most us hello help here " +
            "thanks thank please keyboard android kotlin developer tomorrow today welcome where why yes " +
            "okay morning night love friend great"
            ).split(" ")

        private val DEFAULT_AR = (
            "في من على إلى أن هذا هذه ما لا هل كيف أين متى لماذا ماذا مرحبا السلام عليكم ورحمة الله " +
            "وبركاته أهلا وسهلا شكرا جزيلا عفوا فضلك نعم صباح الخير مساء النور اليوم غدا الآن كل بعد " +
            "قبل مع عن أنا أنت هو هي نحن هم الكيبورد تطبيق برمجة أندرويد محمد أحمد علي مصر السعودية " +
            "العربية اللغة الحمد لله إن شاء بارك العافية كتاب بيت عمل صديق حب وقت لكن أو ثم لقد كان " +
            "يكون قد حتى"
            ).split(" ")
    }
}

/** كلمة مرشّحة للكتابة بالسحب: العرض، المفتاح المُطبَّع، الترتيب */
class GlideWord(val word: String, val key: String, val rank: Int)
