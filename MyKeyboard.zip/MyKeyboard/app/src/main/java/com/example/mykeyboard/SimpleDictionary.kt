package com.example.mykeyboard

import android.content.Context
import java.io.File
import java.util.TreeMap

/**
 * قاموس يدعم عشرات الآلاف من الكلمات.
 *
 * مصادر التحميل بالترتيب:
 *  1) ملف استوردته من التطبيق (filesDir/words_en.txt أو words_ar.txt)
 *  2) ملف في assets (يُنزَّل تلقائياً عند البناء على GitHub)
 *  3) قائمة صغيرة مدمجة
 *
 * صيغة الملف: كلمة في كل سطر، الأكثر شيوعاً أولاً.
 * يُقبل أيضاً سطر بالصيغة "كلمة عدد" (مثل ملفات FrequencyWords).
 */
class SimpleDictionary(private val context: Context) {

    private class Entry(val word: String, val rank: Int)

    @Volatile private var enIndex: TreeMap<String, Entry> = build(DEFAULT_EN, false)
    @Volatile private var arIndex: TreeMap<String, Entry> = build(DEFAULT_AR, true)
    private var enStamp = -1L
    private var arStamp = -1L

    init {
        refreshIfNeeded()
    }

    /** يعيد تحميل القواميس (في خيط خلفي) إذا تغيّر الملف المستورد */
    @Synchronized
    fun refreshIfNeeded() {
        val en = stamp(EN_FILE)
        if (en != enStamp) {
            enStamp = en
            loadAsync(false)
        }
        val ar = stamp(AR_FILE)
        if (ar != arStamp) {
            arStamp = ar
            loadAsync(true)
        }
    }

    private fun stamp(name: String): Long {
        val f = File(context.filesDir, name)
        return if (f.exists()) f.lastModified() else 0L
    }

    private fun loadAsync(arabic: Boolean) {
        Thread {
            val lines = readLines(if (arabic) AR_FILE else EN_FILE)
            if (lines != null) {
                val index = build(lines, arabic)
                if (arabic) arIndex = index else enIndex = index
            }
        }.start()
    }

    private fun readLines(name: String): List<String>? = try {
        val f = File(context.filesDir, name)
        if (f.exists() && f.length() > 0) {
            f.bufferedReader().useLines { it.take(MAX_LINES).toList() }
        } else {
            context.assets.open(name).bufferedReader().useLines { it.take(MAX_LINES).toList() }
        }
    } catch (e: Exception) {
        null // لا يوجد ملف: نبقى على القائمة المدمجة
    }

    // ------------------------------------------------------------------ البناء والبحث

    private fun isMark(c: Char) = c in '\u064B'..'\u065F' || c == '\u0670' || c == '\u0640'

    /** مفتاح البحث: أحرف صغيرة، وفي العربية نحذف التشكيل والتطويل */
    private fun norm(w: String, arabic: Boolean): String {
        val lower = w.lowercase()
        if (!arabic) return lower
        // نحذف التشكيل ونوحّد صور الألف والياء والتاء المربوطة ليتسامح البحث مع الأخطاء الإملائية
        return buildString {
            for (c in lower) {
                if (isMark(c)) continue
                append(
                    when (c) {
                        'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                        'ى' -> 'ي'
                        'ة' -> 'ه'
                        else -> c
                    }
                )
            }
        }
    }

    private fun build(lines: List<String>, arabic: Boolean): TreeMap<String, Entry> {
        val map = TreeMap<String, Entry>()
        var rank = 0
        for (raw in lines) {
            val line = raw.trim().trimStart('\uFEFF')
            val cut = line.indexOfFirst { it.isWhitespace() }
            val word = if (cut >= 0) line.substring(0, cut) else line
            if (word.isEmpty() || word.length > 24 || !word.first().isLetter()) continue
            if (!word.all { it.isLetter() || it == '\'' || (arabic && isMark(it)) }) continue
            if (word.length == 1 && (arabic || word.lowercase() !in setOf("a", "i"))) continue
            val key = norm(word, arabic)
            if (!map.containsKey(key)) map[key] = Entry(word, rank++)
        }
        return map
    }

    private fun userPrefs(isArabic: Boolean) = context.getSharedPreferences(
        if (isArabic) "user_dict_ar" else "user_dict_en", Context.MODE_PRIVATE
    )

    fun suggest(prefix: String, isArabic: Boolean, max: Int = 3): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val key = norm(prefix, isArabic)
        if (key.isEmpty()) return emptyList()
        val capitalize = !isArabic && prefix.first().isUpperCase()

        // كلمات المستخدم أولاً (الأكثر استخداماً)
        val user = userPrefs(isArabic).all.entries
            .filter {
                it.key.startsWith(prefix, ignoreCase = true) &&
                    !it.key.equals(prefix, ignoreCase = true)
            }
            .sortedByDescending { (it.value as? Int) ?: 0 }
            .map { it.key }

        // ثم أشيع الكلمات في القاموس التي تبدأ بالمدخل
        val index = if (isArabic) arIndex else enIndex
        val best = ArrayList<Entry>(max + 1)
        for ((k, e) in index.subMap(key, true, key + '\uffff', true)) {
            if (k == key) continue
            var pos = best.size
            while (pos > 0 && best[pos - 1].rank > e.rank) pos--
            if (pos < max) {
                best.add(pos, e)
                if (best.size > max) best.removeAt(best.size - 1)
            }
        }

        return (user + best.map { it.word }).distinct().take(max).map { w ->
            if (capitalize) w.replaceFirstChar { it.uppercase() } else w
        }
    }

    /** هل توجد كلمة عربية تبدأ بهذا المفتاح (مُطبَّع)؟ */
    fun arabicHasPrefix(key: String): Boolean {
        val k = arIndex.ceilingKey(key)
        return k != null && k.startsWith(key)
    }

    /** أفضل كلمات عربية تبدأ بالمفتاح: (الكلمة، الدرجة) والأقل أفضل */
    fun arabicMatches(key: String, max: Int): List<Pair<String, Int>> {
        val best = ArrayList<Pair<String, Int>>(max + 1)
        for ((k, e) in arIndex.subMap(key, true, key + '\uffff', true)) {
            val score = e.rank + (k.length - key.length) * 400
            var pos = best.size
            while (pos > 0 && best[pos - 1].second > score) pos--
            if (pos < max) {
                best.add(pos, Pair(e.word, score))
                if (best.size > max) best.removeAt(best.size - 1)
            }
        }
        return best
    }

    /** يحفظ الكلمة التي كتبها المستخدم ليقترحها لاحقاً */
    fun learn(word: String, isArabic: Boolean) {
        val w = if (isArabic) word else word.lowercase()
        if (w.length < 2 || !w.all { it.isLetter() || it == '\'' }) return
        val p = userPrefs(isArabic)
        p.edit().putInt(w, p.getInt(w, 0) + 1).apply()
    }

    companion object {
        const val EN_FILE = "words_en.txt"
        const val AR_FILE = "words_ar.txt"
        private const val MAX_LINES = 80_000

        private val DEFAULT_EN = (
            "the be to of and a in that have I it for not on with he as you do at this but his by from " +
            "they we say her she or an will my one all would there their what so up out if about who get " +
            "which go me when make can like time no just him know take people into year your good some " +
            "could them see other than then now look only come its over think also back after use two how " +
            "our work first well way even new want because any these give day most us hello help here " +
            "thanks thank please keyboard android kotlin developer tomorrow today welcome where why yes " +
            "okay morning night love friend great"
            ).split(" ")

        private val DEFAULT_AR = (
            "في من على إلى أن هذا هذه ما لا هل كيف أين متى لماذا ماذا مرحبا السلام عليكم ورحمة الله " +
            "وبركاته أهلا وسهلا شكرا جزيلا عفوا فضلك نعم صباح الخير مساء النور اليوم غدا الآن كل بعد " +
            "قبل مع عن أنا أنت هو هي نحن هم الكيبورد تطبيق برمجة أندرويد محمد أحمد علي مصر السعودية " +
            "العربية اللغة الحمد لله إن شاء بارك العافية كتاب بيت عمل صديق حب وقت لكن أو ثم لقد كان " +
            "يكون قد حتى"
            ).split(" ")
    }
}
