package com.example.mykeyboard

enum class Mode { ENGLISH, ARABIC, SYMBOLS1, SYMBOLS2, EMOJI }

/** label = ما يظهر على الزر، text = ما يُكتب فعلياً */
data class Key(val label: String, val text: String = label)

object KeyboardLayouts {

    private fun rows(vararg rows: String): List<List<Key>> =
        rows.map { r -> r.map { Key(it.toString()) } }

    val english = rows("qwertyuiop", "asdfghjkl", "zxcvbnm")

    val arabic: List<List<Key>> = listOf(
        listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د"),
        listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"),
        listOf("ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ")
    ).map { r -> r.map { Key(it) } }

    /** عند الضغط على Shift في العربية: يُستبدل الصف الأول بالتشكيل */
    private const val DOTTED = "\u25CC"
    val arabicMarks: List<Key> = listOf(
        "\u064B", "\u064C", "\u064D", "\u064E", "\u064F", "\u0650",
        "\u0651", "\u0652", "\u0653", "\u0654", "\u0670"
    ).map { Key(DOTTED + it, it) } + Key("\u0640\u0640", "\u0640")

    val symbols1 = rows("1234567890", "@#\$%&-+()/", "*\"':;!?")
    val symbols2 = rows("1234567890", "~|\\^[]{}<>", "=_€£¥،؟")

    val emojis: List<String> = (
        "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 " +
        "😎 🤩 🥳 😏 😒 😞 😔 😢 😭 😤 😠 😡 🤯 😱 😨 😰 " +
        "🤔 🤗 🤭 🙄 😴 🤒 😷 🥵 🥶 👍 👎 👏 🙌 🙏 💪 👌 " +
        "✌️ 🤝 👋 🤞 👀 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 💕 💯 🔥 " +
        "✨ ⭐ 🌟 🎉 🎊 🎁 🚀 💡 ✅ ❌ ⚠️ ☕ 🍕 🍔 🍎 🌹 " +
        "🌙 ☀️ 🌈 🎵 ⚽ 🚗 ✈️ 🏠 📱 💻 📷 🔔 💰 👑 🕌 🤲"
        ).split(" ")
}
