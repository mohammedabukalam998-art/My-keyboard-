package com.example.mykeyboard

enum class Mode { ENGLISH, ARABIC, SYMBOLS1, SYMBOLS2, EMOJI, CLIPBOARD }

/** label = ما يظهر على الزر، text = ما يُكتب فعلياً */
data class Key(val label: String, val text: String = label)

object KeyboardLayouts {

    private fun rows(vararg rows: String): List<List<Key>> =
        rows.map { r -> r.map { Key(it.toString()) } }

    val english = rows("qwertyuiop", "asdfghjkl", "zxcvbnm")
    val digits = rows("1234567890")

    val arabic: List<List<Key>> = listOf(
        listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د"),
        listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"),
        listOf("ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ")
    ).map { r -> r.map { Key(it) } }

    /** عند الضغط على Shift في العربية: يُستبدل الصف الأول بالتشكيل */
    private const val DOTTED = "\u25CC"
    val arabicMarks: List<Key> = listOf(
        "\u064B", "\u064C", "\u064D", "\u064E", "\u064F", "\u0650",
        "\u0651", "\u0652", "\u0653", "\u0654", "\u0670"
    ).map { Key(DOTTED + it, it) } + Key("\u0640\u0640", "\u0640")

    /** رموز بديلة تظهر عند الضغط المطوّل على المفتاح */
    private val baseAlt: Map<String, List<String>> = mapOf(
        // إنجليزي
        "a" to "àáâäæãåā", "c" to "çćč", "e" to "èéêëēėę", "g" to "ğ", "i" to "îïíīįì",
        "l" to "ł", "n" to "ñń", "o" to "ôöòóœøōõ", "s" to "śšß", "u" to "ûüùúū",
        "y" to "ýÿ", "z" to "žźż",
        // عربي
        "ا" to "أإآءٱ", "و" to "ؤ", "ي" to "ئىی", "ه" to "ة", "ك" to "گ",
        "ب" to "پ", "ج" to "چ", "ف" to "ڤ", "ز" to "ژ",
        // رموز
        "-" to "–—•", "\$" to "€£¥¢", "?" to "¿", "!" to "¡", "'" to "‘’‚",
        "\"" to "“”«»", "%" to "‰", "0" to "°", "+" to "±", "=" to "≠≈",
        "<" to "≤«", ">" to "≥»", "*" to "•†", "&" to "§"
    ).mapValues { entry -> entry.value.map { it.toString() } }

    /** الضغط المطوّل على رقم يعطي مقابله: 3 ↔ ٣ */
    private val digitAlts: Map<String, List<String>> = (0..9).flatMap { d ->
        val w = ('0' + d).toString()
        val e = ('\u0660' + d).toString()
        listOf(w to listOf(e), e to listOf(w))
    }.toMap()

    private val altMap: Map<String, List<String>> =
        baseAlt + digitAlts + mapOf("0" to listOf("\u0660", "°"))

    fun alternatesFor(text: String, arabic: Boolean): List<String>? = when (text) {
        "." -> if (arabic) listOf("،", "؟", "!", "؛", ":", "-", "…")
               else listOf(",", "?", "!", "'", "\"", ":", ";", "-")
        else -> altMap[text]
    }

    val symbols1 = rows("1234567890", "@#\$%&-+()/", "*\"':;!?")
    val symbols2 = rows("1234567890", "~|\\^[]{}<>", "=_€£¥،؟")

    val emojiCategories: List<EmojiCategory> = listOf(
        EmojiCategory("😀", split(
            "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😎 🤩 🥳 😏 😒 😞 😔 😢 😭 😤 😠 😡 🤯 😱 😨 😰 " +
            "🤔 🤗 🤭 🙄 😴 🤒 😷 🥵 🥶 😬 😳 🥺 😌 😜 🤪 🤓 " +
            "👍 👎 👏 🙌 🙏 💪 👌 ✌️ 🤝 👋 🤞 👀 🤲 👊 ✋ 🤙"
        )),
        EmojiCategory("🐶", split(
            "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦆 🦅 🦉 🐺 🐴 🦄 " +
            "🐝 🦋 🐢 🐍 🐙 🐬 🐳 🦈 🐘 🦒 🐪 🌵 🌴 🌳 🌹 🌻 🌸 🍀 🌙 ☀️ 🌈 ⭐ ☁️ ❄️"
        )),
        EmojiCategory("🍔", split(
            "🍎 🍌 🍇 🍓 🍉 🍑 🍍 🥭 🍒 🥝 🍅 🥑 🥕 🌽 🥔 🍞 🧀 🍳 🥞 🍗 🍔 🍟 🍕 🌭 " +
            "🌮 🍣 🍜 🍝 🍩 🍪 🎂 🍰 🍫 🍿 ☕ 🍵 🥤 🍺 🍷 🍯"
        )),
        EmojiCategory("⚽", split(
            "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏓 🏸 🥊 🎯 🎮 🎲 🎸 🎹 🎤 🎧 🎬 🎨 🏆 🥇 🎉 🎊 🎁 🎈 🏊 🚴 🏃 🧘"
        )),
        EmojiCategory("🚗", split(
            "🚗 🚕 🚌 🚓 🚑 🚒 🚚 🚲 🏍️ ✈️ 🚀 🚁 🚢 ⛵ 🚂 🏠 🏢 🏥 🏫 🕌 ⛪ 🏖️ 🏔️ 🌍 🗺️ ⏰ ⌛"
        )),
        EmojiCategory("💡", split(
            "💡 📱 💻 ⌨️ 🖥️ 📷 🔋 🔌 💰 💳 📚 ✏️ 📝 📌 📎 ✂️ 🔑 🔒 🔔 🧰 🔧 ⚙️ 💊 🛒 👑 💎"
        )),
        EmojiCategory("❤️", split(
            "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 💔 💕 💯 ✨ 🌟 🔥 💥 ✅ ❌ ⚠️ ❓ ❗ ➕ ➖ ✔️ ♻️ " +
            "🔴 🟢 🔵 ⚪ ⬆️ ⬇️ ➡️ ⬅️ 🔁"
        ))
    )

    private fun split(s: String): List<String> = s.split(" ").filter { it.isNotEmpty() }
}

data class EmojiCategory(val icon: String, val emojis: List<String>)
