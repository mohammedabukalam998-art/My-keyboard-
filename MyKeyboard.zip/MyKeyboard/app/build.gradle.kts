plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.mykeyboard"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.mykeyboard"
        minSdk = 26
        targetSdk = 34
        // رقم الإصدار يزيد تلقائياً مع كل بناء (دقائق منذ 1970) ليقبله أندرويد كتحديث فوق النسخة السابقة
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "dev")
    }

    // مفتاح توقيع ثابت: شرط أساسي حتى يُثبَّت كل إصدار فوق السابق دون حذفه
    signingConfigs {
        create("fixed") {
            storeFile = file("mykeyboard.p12")
            storeType = "pkcs12"
            storePassword = "RZMU3A01pvQuBB0R4h8yhMol"
            keyAlias = "mykeyboard"
            keyPassword = "RZMU3A01pvQuBB0R4h8yhMol"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
}
